package data;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Clock;

public class CreateGame {
	Level level;
	GameHandler game;
	Spawn enemySpawn;
	Tower tower;
	TileGrid grid;
	
	public CreateGame(){
		Level level = new Level();
		level.nextLevel();
		
		this.enemySpawn = new Spawn(level.getMaxEnemy());
		this.grid = new TileGrid(level.getMap());
		this.game = new GameHandler(grid.getPath(), grid.getTileMap(), enemySpawn, grid.getSpawnPoint(), grid.getEndPoint(), level);
		this.tower = new Tower("Basic",grid.GetTile(7, 1), TowerType.Basic, game.GetSpawner().getEnemyList());
		
	}
	
	public void update(){
		Clock.update();
		grid.Draw();
		
		game.Update();
		game.Movement();
		
		tower.update();
		tower.updateEnemyList(game.GetSpawner().getEnemyList());
		
	}
}
