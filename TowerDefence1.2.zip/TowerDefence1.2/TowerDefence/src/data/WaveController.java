package data;
public class WaveController {
	
	public Level currLevel;
	public Spawn spawner;
	public int currEnemies;
	public int currWave;
	public WaveController(Level currLevel, Spawn spawner){
		this.currLevel = currLevel;
		this.spawner = spawner;
		this.currEnemies = 0;
		this.currWave = 0;
	}
	
	public void SetWave(int currWave){
		this.currWave = currWave;
	}
	
	public int GetWave(){
		return currWave;
	}
	
	
}
