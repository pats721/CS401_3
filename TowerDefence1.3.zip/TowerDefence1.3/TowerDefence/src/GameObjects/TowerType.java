package GameObjects;

public enum TowerType {
	BasicSquirt("gun64", 250, 5, 3, 1, 10, 10), MediumSatellite("satellite64", 250, 5, 3, 1, 10, 10), HighVolcano("volcano64", 250, 5, 3, 1, 10, 10);
	
	String texture;
	double range;
	int tcost;
	int upcost;
	int baseattack;
	int maxattack;
	float fire;
	
	TowerType(String texture, double range, int tcost, int upcost, int baseattack, int maxattack, float fire) {
		this.texture = texture;
		this.range = range;
		this.tcost = tcost;
		this.upcost = upcost;
		this.baseattack = baseattack;
		this.maxattack = maxattack;
		this.fire = fire;
	}
}