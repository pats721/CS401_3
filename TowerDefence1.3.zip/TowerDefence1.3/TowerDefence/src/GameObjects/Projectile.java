package GameObjects;

import org.newdawn.slick.opengl.Texture;

import data.Enemy;

import static helpers.Clock.*;

import java.util.ArrayList;

import static helpers.Artist.*;

public class Projectile {

	private Texture texture;
	private float x, y, width, hight, speed, xSpeed, ySpeed;
	private int damage;
	private boolean first = false;
	private Enemy target;
	private boolean alive;

	public Projectile(Texture texture, float x, float y, float width, float hight, float speed, int damage,
			Enemy target) {
		this.texture = texture;
		this.x = x;
		this.y = y;
		this.speed = speed;
		this.damage = damage;
		this.target = target;
		this.xSpeed = 0f;
		this.ySpeed = 0f;
		this.alive = true;
		this.width = width;
		this.hight = hight;
		aim();
	}

	private void aim() {
		if (this.target != null) {
			float totalAllowedMovement = 1.0f;
			float xDistance = Math.abs(target.getX() - x);
			float yDistance = Math.abs(target.getY() - y);
			float totalDistance = xDistance + yDistance;
			float xPercentofMovement = xDistance / totalDistance;

			this.xSpeed = xPercentofMovement;
			this.ySpeed = totalAllowedMovement - xPercentofMovement;

			if (target.getX() < x)
				this.xSpeed *= -1;
			if (target.getY() < y)
				this.ySpeed *= -1;
		}
	}

	public void update() {
		if (this.target != null) {
			if (alive) {
				x += this.xSpeed * speed * Delta();
				y += this.ySpeed * speed * Delta();
				if (CheckCollision(x, y, width, hight, target.getX(), target.getY(), target.getWidth(),
						target.getHight()))
					this.alive = false;
				draw();
			}
		}
	}

	public void draw() {
		DrawQuadTex(texture, x, y, 32, 32);
	}
}