package helpers;

import data.Level;
import data.MainMenu;
import helpers.Artist.*;

public class UIselector {
	
	public static boolean isPlaying = false;
	public static enum UIState {
		MAINMENU, LEVEL
	}
	public static UIState uiState = UIState.MAINMENU;
	public static MainMenu mainMenu;
	public static Level level;

	public static void update() {
		
		switch(uiState) {
		
		case MAINMENU:
			if (mainMenu == null)
				mainMenu = new MainMenu();
			mainMenu.update();
			
			break;
	
		case LEVEL:
			isPlaying = true;
			
			break;
			
		}
	}
	
	public static void setUI(UIState newUI) {
		uiState = newUI;
		
	}
	
	public static boolean isPlaying(){
		if(isPlaying){
			return true;
		}else{
			return false;
		}
	}
}
