package data;

import org.lwjgl.Sys;

import static helpers.Clock.*;

public class GameHandler {
	Tile[] path;
	Tile[][] map;
	Spawn spawner;
	WaveController waveCont;
	Tile spawnPoint;
	Tile endPoint;
	public int maxEnemyCount;
	public int enemyCount;
	public float timeSinceLastSpawn = 0;
	public int spawnSpeed = 20;
	public Level currLevel;
	public boolean enemiesAlive = true;
	
	public GameHandler(Tile[] path, Tile[][] map, Spawn spawner, Tile spawnPoint, Tile endPoint, Level currLevel){
		this.path = path;
		this.map = map;
		this.spawner = spawner;
		this.maxEnemyCount = spawner.GetEnemyCount();
		this.enemyCount = 0;
		this.spawnPoint = spawnPoint;
		this.endPoint = endPoint;
		this.waveCont = new WaveController(currLevel, spawner);
		Spawn();
	}	
	
	public void Update(){
		timeSinceLastSpawn += Delta();
		System.out.println(timeSinceLastSpawn);
		if(timeSinceLastSpawn > spawnSpeed){
			Spawn();
		}
	}
	
	public void CheckIfAlive(){
		spawner.CheckIfAlive();
	}
	public void Spawn(){
		timeSinceLastSpawn = 0;
			spawner.SpawnEnemy(spawnPoint, endPoint, path);
	}
	
	public void Movement(){
		spawner.Move();
		spawner.DrawEnemy();
	}
	public float GetEnemyX(){
		return spawner.getFirstEnemyX();
	}
	
	public float GetEnemyY(){
		return spawner.getFirstEnemyY();
	}
	
	public Spawn GetSpawner() {
		return this.spawner;
	
	}
}
