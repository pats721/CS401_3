package data;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.newdawn.slick.opengl.Texture;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Clock;
import helpers.UIselector;

import static org.lwjgl.opengl.GL11.*;
import static helpers.Artist.*;

public class Boot{
	private static final int GL_PROTECTION = 0;
	public Boot() {
		
		BeginSession();
		
		CreateGame game = new CreateGame();
		
		while (!Display.isCloseRequested()){
			UIselector.update();
			if(UIselector.isPlaying() == true){
				game.update();
			}
			
			
			Display.update();
			Display.sync(60);
			
			
		}
		Display.destroy();
	}
	
	public static void main(String[] args){
		new Boot();
	}
}
