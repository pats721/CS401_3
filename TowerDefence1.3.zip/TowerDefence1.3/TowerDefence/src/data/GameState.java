package data;

public enum GameState {
	Main_Menu, Game;
}
