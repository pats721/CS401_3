package data;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Clock;

public class CreateGame {
	Level level;
	GameHandler game;
	Spawn enemySpawn;
	Tower tower1, tower2, tower3;
	TileGrid grid;
	
	public CreateGame(){
		Level level = new Level();
		level.nextLevel();
		
		this.enemySpawn = new Spawn(level.getMaxEnemy());
		this.grid = new TileGrid(level.getMap());
		this.game = new GameHandler(grid.getPath(), grid.getTileMap(), enemySpawn, grid.getSpawnPoint(), grid.getEndPoint(), level);
		this.tower1 = new Tower("Basic",grid.GetTile(14, 9), TowerType.BasicSquirt, game.GetSpawner().getEnemyList());
		this.tower2 = new Tower("Basic",grid.GetTile(7, 1), TowerType.MediumSatellite, game.GetSpawner().getEnemyList());
		this.tower3 = new Tower("Basic",grid.GetTile(10, 8), TowerType.HighVolcano, game.GetSpawner().getEnemyList());
	}
	
	public void update(){
		Clock.update();
		grid.Draw();
		
		game.Update();
		game.Movement();
		
		tower1.update();
		tower1.updateEnemyList(game.GetSpawner().getEnemyList());
		tower2.update();
		tower2.updateEnemyList(game.GetSpawner().getEnemyList());
		tower3.update();
		tower3.updateEnemyList(game.GetSpawner().getEnemyList());
		
	}
}
