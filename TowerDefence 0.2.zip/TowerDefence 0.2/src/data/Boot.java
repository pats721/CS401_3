package data;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.newdawn.slick.opengl.Texture;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Clock;

import static org.lwjgl.opengl.GL11.*;
import static helpers.Artist.*;

public class Boot{
	
	public Boot() {
		BeginSession();

		Level level = new Level();
		level.nextLevel();
		Spawn enemySpawn = new Spawn(level.getMaxEnemy());
		TileGrid grid = new TileGrid(level.getMap());
		GameHandler game = new GameHandler(grid.getPath(), grid.getTileMap(), enemySpawn, grid.getSpawnPoint());
		Tower tower = new Tower("Basic",grid.GetTile(7, 1), TowerType.Basic);
		while (!Display.isCloseRequested()){
		Clock.update();
		grid.Draw();
		game.Movement();
		tower.update(game.GetEnemyX(), game.GetEnemyY());
		
		Display.update();
		Display.sync(60);
			
			
		}
		Display.destroy();
	}
	
	public static void main(String[] args){
		new Boot();
	}
}
