package GameObjects;

import org.newdawn.slick.opengl.Texture;

import static helpers.Clock.*;
import static helpers.Artist.*;

public class Projectile {
	
	private Texture texture;
	private float x, y, aimX, aimY, speed;
	private int damage;
	private boolean first = false;
	
	public Projectile(Texture texture, float x, float y, float aimX, float aimY, float speed, int damage){
		this.texture = texture;
		this.x = x;
		this.y = y;
		this.aimX = aimX;
		this.aimY = aimY;
		this.speed = speed;
		this.damage = damage;
	}
	
	public void update() {
		
		if (first) {
			first = false;
		}else {
			if (aimX < x){
				x -= Delta() * speed;
			} else {
				x += Delta() * speed;
			}
			
			if (aimY < y){
				y -= Delta() * speed;
			} else {
				y += Delta() * speed;
			}
		}
		
		draw();
		
	}
	
	public void draw() {
		DrawQuadTex(texture, x, y, 32, 32);
	}
}
