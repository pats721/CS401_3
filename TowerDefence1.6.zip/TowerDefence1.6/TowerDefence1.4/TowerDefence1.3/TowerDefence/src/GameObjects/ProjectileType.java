package GameObjects;

import org.newdawn.slick.opengl.Texture;

public enum ProjectileType {
	Squirt("shootwater"), Lightning("bolt32"), Volcono("Fire32"); 

	String texture;
//	int basedamage;
//	int maxdamage;
	
	ProjectileType(String tex) {
		texture = tex;
//		this.basedamage = basedamage;
//		this.maxdamage = maxdamage;
	}
}