package data;

import java.util.ArrayList;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Clock;

public class CreateGame {
	GameHandler game;
	
	public CreateGame(){
		
		this.game = new GameHandler();
	}
	
	public void update(){
		Clock.update();
		game.DrawGrid();
		if(!game.CheckIfAlive()){
		game.UpdateEnemy();
		game.Movement();
		}
		game.UpdateTower();
		if(game.CheckIfAlive()){
			game.nextWave();
		}
		
		
	}
}