package data;

import org.lwjgl.Sys;

import GameObjects.Tower;

import static helpers.Clock.*;

import java.util.ArrayList;

public class GameHandler {
	Tile[] path;
	Tile[][] map;
	TileGrid grid;
	Spawn spawner;
	Tile spawnPoint;
	Tile endPoint;
	Player user;
	public int maxEnemyCount;
	public int enemyCount;
	public float timeSinceLastSpawn = 0;
	public int spawnSpeed = 20;
	public Level currLevel;
	public boolean enemiesAlive = true;
	private Tower t;
	private ArrayList<Tower> towerList;
	private ArrayList<Enemy> enemies;
	private GameMenu ui;
	
	public GameHandler(){
		
		this.currLevel = new Level();
		this.spawner = new Spawn(currLevel.getMaxEnemy());
		this.grid = new TileGrid(currLevel.getMap());
		this.map = grid.getTileMap();
		this.path = grid.getPath();
		this.maxEnemyCount = currLevel.getMaxEnemy();
		this.enemyCount = 0;
		this.spawnPoint = grid.getSpawnPoint();
		this.endPoint = grid.getEndPoint();
		this.enemies = spawner.getEnemyList();
		this.user = new Player(this.grid, this.enemies, this.ui);
		this.towerList = user.getTowerList();
		Spawn();
	}
	
	public void DrawGrid(){
		grid.Draw();
	}
	
	public void UpdateEnemy(){
		timeSinceLastSpawn += Delta();
		System.out.println(timeSinceLastSpawn);
		if(timeSinceLastSpawn > spawnSpeed){
			Spawn();
		}
	}
	
	public void UpdateTower(){
		user.update();
		this.towerList = user.getTowerList();
		for(Tower t: towerList){
			t.updateEnemyList(this.enemies);
			t.update();
			this.enemies = t.getEnemies();
			DestroyEnemies();
		}
	}
	
	public void DestroyEnemies(){
		ArrayList<Enemy> locEnemies = this.enemies;
		int locEnemyCount=0;
			for(Enemy e: enemies){
				if(e.getHealth() <= 0){
					locEnemies.get(e.getIndex()).die();
				}
				locEnemyCount++;
			}this.enemies = locEnemies;
		}
	
	public void CheckIfAlive(){
		DestroyEnemies();
		spawner.CheckIfAlive();
	}
	
	public void Spawn(){
		timeSinceLastSpawn = 0;
			spawner.SpawnEnemy(spawnPoint, endPoint, path);
	}
	
	public void Movement(){
		spawner.Move();
		spawner.DrawEnemy();
	}
	public float GetEnemyX(){
		return spawner.getFirstEnemyX();
	}
	
	public float GetEnemyY(){
		return spawner.getFirstEnemyY();
	}
	
	public Spawn GetSpawner() {
		return this.spawner;
	}
	
	public void addTower(Tower t){
		towerList.add(t);
	}
}
