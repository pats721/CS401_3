package data;

import org.lwjgl.Sys;
import static helpers.Clock.*;
public class GameHandler {
	Tile[] path;
	Tile[][] map;
	Spawn spawner;
	Tile spawnPoint;
	Tile endPoint;
	public int maxEnemyCount;
	public int enemyCount;
	public float timeSinceLastSpawn = 0;
	public int spawnSpeed = 20;
	
	public GameHandler(Tile[] path, Tile[][] map, Spawn spawner, Tile spawnPoint, Tile endPoint){
		this.path = path;
		this.map = map;
		this.spawner = spawner;
		this.maxEnemyCount = spawner.GetEnemyCount();
		this.enemyCount = 0;
		this.spawnPoint = spawnPoint;
		this.endPoint = endPoint;
		Spawn();
	}	
	
	public void Update(){
		timeSinceLastSpawn += getDelta();
		System.out.println(timeSinceLastSpawn);
		if(timeSinceLastSpawn > spawnSpeed){
			Spawn();
		}
	}
	
	public void Spawn(){
		timeSinceLastSpawn = 0;
		spawner.SpawnEnemy(spawnPoint, endPoint, path);
	}
	
	public void Movement(){
		spawner.Move();
		spawner.DrawEnemy();
	}
}
