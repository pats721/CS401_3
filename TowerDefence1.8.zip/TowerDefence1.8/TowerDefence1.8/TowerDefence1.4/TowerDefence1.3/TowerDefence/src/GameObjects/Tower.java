
package GameObjects;

import org.newdawn.slick.opengl.Texture;

import java.util.ArrayList;
import java.util.Random;

import static helpers.Artist.*;
import static helpers.Clock.*;

import data.*;

public class Tower {
	final static int MAXLEVEL = 5;

	private String name;
	private int baseattack;
	private int maxattack;
	private double range;
	private int tcost;
	private int upcost;
	private int level;
	private Texture texture;
	private TowerType type;
	private Tile startTile;
	private float x, y, width, hight, timeSinceLastShot, firingSpeed, angle;
	private ArrayList<Projectile> projectile;
	private ArrayList<Enemy> enemies;
	private Enemy targetEnemy;
	private int targetEnemyIndex;
	private boolean targeted;

	public Tower(String name, Tile startTile, TowerType type) {
		this.name = name;
		this.startTile = startTile;
		this.x = startTile.getX();
		this.y = startTile.getY();
		this.type = type;
		this.baseattack = type.baseattack;
		this.maxattack = type.maxattack;
		this.tcost = type.tcost;
		this.upcost = type.upcost;
		this.level = 1;
		this.texture = QuickLoad(type.texture);
		this.range = type.range;
		this.width = startTile.getWidth();
		this.hight = startTile.getHight();
		this.firingSpeed = type.fire;
		this.projectile = new ArrayList<Projectile>();
		this.enemies = null;
		this.targetEnemy = null;
		this.angle = getAngle();
		this.targeted = false;
	}
	private Enemy getTarget() {
		Enemy closestEnemy = null;
		float closestDistance = (float) this.range;
		for (Enemy e : enemies) {
			if (inRange(e) && getDistance(e) < closestDistance) {
				closestDistance = getDistance(e);
				closestEnemy = e;
			}
		}
		if (closestEnemy != null)
			this.targeted = true;
		return closestEnemy;
	}

	private boolean inRange(Enemy e) {
		float xDistance = Math.abs(e.getX() - x);
		float yDistance = Math.abs(e.getY() - y);

		if (xDistance < this.range && yDistance < this.range)
			return true;
		return false;
	}

	private float getDistance(Enemy e) {
		float xDistance = Math.abs(e.getX() - x);
		float yDistance = Math.abs(e.getY() - y);

		return xDistance + yDistance;
	}

	private float getAngle() {
		if (this.targetEnemy != null) {
			double tempAngle = Math.atan2(targetEnemy.getY() - y, targetEnemy.getX() - x);
			return (float) Math.toDegrees(tempAngle) - 90;
		}
		return 0f;
	}

	private void shoot() {
		if (this.targetEnemy != null && this.targetEnemy.isAlive() == true) {
			if (inRange(this.targetEnemy)) {
				timeSinceLastShot = 0;
				if (this.type == TowerType.BasicSquirt) {
				projectile.add(
						new Projectile(x + 32, y + 32, 32, 32, 100, 1, this.targetEnemy, ProjectileType.Squirt));
				}
				if (this.type == TowerType.MediumSatellite) {
					projectile.add(
							new Projectile(x + 32, y + 32, 32, 32, 100, 1, this.targetEnemy, ProjectileType.Lightning));
				}
				if (this.type == TowerType.HighVolcano) {
					projectile.add(
							new Projectile(x + 32, y + 32, 32, 32, 100, 1, this.targetEnemy, ProjectileType.Volcono));
				}
			}
		}
	}

	public void updateEnemyList(ArrayList<Enemy> newList) {
		enemies = newList;
	}

	public void update() {
		this.targeted = false;
		if (!this.targeted) {
			this.targetEnemy = getTarget();
		}
		if (this.targetEnemy == null || this.targetEnemy.isAlive() == false)
			this.targeted = false;

		timeSinceLastShot += Delta();
		if (timeSinceLastShot > firingSpeed)
			shoot();

		for (Projectile p : projectile){
			p.update();
			if(p.isAlive() != true){
				for(int i = 0; i < enemies.size(); i++){
					if(p.getTargetIndex() == i){
						enemies.remove(i);
						enemies.add(i, p.getTarget());
					}
				}
			}
		}

		this.angle = getAngle();
		DrawTower();
	}

	public void DrawTower() {
		DrawQuadTex(this.texture, this.x, this.y, this.width, this.hight);
	}

	public int Attack() {
		Random rand = new Random();
		return rand.nextInt(this.maxattack) + this.baseattack;
	}

	public void UpgradeTower() {
		if (this.level != MAXLEVEL) {
			this.level = this.level + 1;
			this.baseattack = this.baseattack + 5;
			this.maxattack = this.maxattack + 5;
		} else {

		}

	}

	public int getTcost() {
		return tcost;
	}

	public double getRange() {
		return range;
	}

	public int getUpcost() {
		return upcost;
	}
	
	public int getTargetHealth(){
		return this.targetEnemy.getHealth();
	}
	
	public ArrayList<Enemy> getEnemies(){
		return this.enemies;
	}

}