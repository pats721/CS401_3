package data;

import java.util.ArrayList;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Clock;
import helpers.UIselector;

public class CreateGame {
	GameHandler game;
	public CreateGame(){
		this.game = new GameHandler();
	}
	
	public void update(){
		UIselector.update();
		if(UIselector.isPlaying() == true){
			Clock.update();
				game.DrawGrid();
				game.updateGameMenu();
				if(!game.CheckIfAlive()){
				game.UpdateEnemy();
				game.Movement();
				}
				game.UpdateTower();
				if(game.CheckIfAlive()){
					game.nextWave();
				}
				if(game.isEnd()){
					UIselector.setMainMenu();
				}
		}
	}
}