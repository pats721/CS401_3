package data;

import org.lwjgl.Sys;
import org.newdawn.slick.Color;
import org.newdawn.slick.TrueTypeFont;
import org.newdawn.slick.util.ResourceLoader;

import GameObjects.Tower;
import helpers.UIselector;

import static helpers.Clock.*;
import static helpers.UIselector.*;
import java.awt.Font;
import java.io.InputStream;
import java.util.ArrayList;

public class GameHandler {
	Tile[] path;
	Tile[][] map;
	TileGrid grid;
	Spawn spawner;
	Tile spawnPoint;
	Tile endPoint;
	Player user;
	public int maxEnemyCount;
	public int enemyCount;
	public float timeSinceLastSpawn = 0;
	private float timeSinceLastWave = 0;
	public int spawnSpeed = 20;
	public Level currLevel;
	public boolean enemiesAlive = true;
	private Tower t;
	private ArrayList<Tower> towerList;
	private ArrayList<Enemy> enemies;
	private GameMenu ui;
	private int score = 0;
	private TrueTypeFont font;
	private Font awtFont;
	private int lives = 1;
	private Text text = new Text();
	private int money = 0;
	public GameHandler(){	
		this.currLevel = new Level();
		this.currLevel.nextLevel();
		this.spawner = new Spawn(currLevel.getMaxEnemy());
		this.grid = new TileGrid(currLevel.getMap());
		this.map = grid.getTileMap();
		this.path = grid.getPath();
		this.maxEnemyCount = currLevel.getMaxEnemy();
		this.enemyCount = 0;
		this.spawnPoint = grid.getSpawnPoint();
		this.endPoint = grid.getEndPoint();
		this.enemies = spawner.getEnemyList();
		this.user = new Player(this.grid, this.enemies, this.ui);
		this.towerList = user.getTowerList();
		awtFont = new Font("Times New Roman", Font.BOLD, 24);
		font = new TrueTypeFont(awtFont, false);
	}
	public void newGame(){
		nextWave();
		
	}
	public boolean isEnd(){
		if(this.lives <= 0){
			return true;
		}return false;
	}
	
	public void updateGameMenu(){
		if(ui!=null)
		ui.update();
	}
	public void nextWave(){
		this.timeSinceLastWave += Delta();
		if(timeSinceLastWave > 300){
			timeSinceLastWave = 0;
			this.spawner = new Spawn(currLevel.getMaxEnemy());
			enemies = spawner.getEnemyList();
			Spawn();
			
		}
	}
	
	public void DrawGrid(){
		grid.Draw();
	}
	
	public void UpdateEnemy(){
		timeSinceLastSpawn += Delta();
		System.out.println(timeSinceLastSpawn);
		if(timeSinceLastSpawn > spawnSpeed){
			Spawn();
			this.enemies = spawner.getEnemyList();
		}
		LifeUpdate();
		Scoring();
	}
	
	public void LifeUpdate(){
		for(Enemy e: enemies){
			if(e.getCurrPosition() == path.length){
				if(!e.getAttacked())
				this.lives = this.lives - e.attackBase();
			}
		}text.drawString(String.valueOf("Lives: " + this.lives),1060, 960);
		
	}
	
	public void UpdateTower(){
		user.update();
		this.towerList = user.getTowerList();
		for(Tower t: towerList){
			t.updateEnemyList(this.enemies);
			t.update();
			this.enemies = t.getEnemies();
			DestroyEnemies();
		}
	}
	
	public void DestroyEnemies(){
		ArrayList<Enemy> locEnemies = this.enemies;
		int locEnemyCount=0;
			for(Enemy e: enemies){
				if(e.getHealth() <= 0){
					locEnemies.get(e.getIndex()).die();
				}
				locEnemyCount++;
			}this.enemies = locEnemies;
	}
	
	public void Scoring(){
		for(Enemy e: enemies){
			if(!e.isAlive() && !e.getGotPoints()){
				this.score += 10;
				this.money += 5;
				e.gotPoints();
				
			}
		}text.drawString("Score: " + String.valueOf(this.score), 450, 960);
		text.drawString("Money: " + String.valueOf(this.money), 750, 960);
		
	}
	
	public boolean CheckIfAlive(){
		return spawner.CheckIfAlive();
	}
	
	public void Spawn(){
		timeSinceLastSpawn = 0;
		spawner.SpawnEnemy(spawnPoint, endPoint, path);
	}
	
	public void Movement(){
		spawner.Move();
		spawner.DrawEnemy();
	}
	public float GetEnemyX(){
		return spawner.getFirstEnemyX();
	}
	
	public float GetEnemyY(){
		return spawner.getFirstEnemyY();
	}
	
	public Spawn GetSpawner() {
		return this.spawner;
	}
	
	public void addTower(Tower t){
		towerList.add(t);
	}
}
