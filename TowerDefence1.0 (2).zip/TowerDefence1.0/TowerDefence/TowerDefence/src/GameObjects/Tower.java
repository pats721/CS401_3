package GameObjects;

import org.newdawn.slick.opengl.Texture;

public class Tower {
	final static int MAXLEVEL = 5;
	
	private String name;
	private	int baseattack;
	private	int maxattack;
	private double range;
	private int tcost;
	private int upcost;
	private int level;
	private Texture texture;
	private float x, y; 
	
public Tower(String name, float x, float y, Texture texture){
	this.name = name;
	this.x = x;
	this.y = y;
	this.baseattack = 1;
	this.maxattack = 10;
	this.range = 0.0;
	this.tcost = 0;
	this.upcost = 0;
	this.level = 1;
	this.texture = texture;
	 }

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getBaseattack() {
	return baseattack;
}

public void setBaseattack(int baseattack) {
	this.baseattack = baseattack;
}

public int getMaxattack() {
	return maxattack;
}

public void setMaxattack(int maxattack) {
	this.maxattack = maxattack;
}

public double getRange() {
	return range;
}

public void setRange(double range) {
	this.range = range;
}

public int getTcost() {
	return tcost;
}

public void setTcost(int tcost) {
	this.tcost = tcost;
}

public int getUpcost() {
	return upcost;
}

public void setUpcost(int upcost) {
	this.upcost = upcost;
}

public int getLevel() {
	return level;
}

public void setLevel(int level) {
	this.level = level;
}

public Texture getTexture() {
	return texture;
}

public void setTexture(Texture texture) {
	this.texture = texture;
}

public float getX() {
	return x;
}

public void setX(float x) {
	this.x = x;
}

public float getY() {
	return y;
}

public void setY(float y) {
	this.y = y;
}

public static int getMaxlevel() {
	return MAXLEVEL;
}
}
