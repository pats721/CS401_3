package data;

public enum EnemyType {
	Fire("Fire32", true), Alien("Alien64", true), Devil("devil64", true), Virus("virus64", true);
	
	String texture;
	boolean build;
	
	EnemyType(String texture, boolean build){
		this.texture = texture;
		this.build = build;
	}
}

