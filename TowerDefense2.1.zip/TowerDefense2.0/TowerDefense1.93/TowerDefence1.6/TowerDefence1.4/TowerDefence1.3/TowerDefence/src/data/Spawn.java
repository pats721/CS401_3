package data;
import java.util.ArrayList;
import java.util.Random;

import GameObjects.Player;
import helpers.Clock;

public class Spawn {
	public ArrayList<Enemy> enemies;
	private EnemyType[] enemyTypes;
	public int enemyCount;
	public int maxEnemy;
	public Tile spawn;
	public Tile[] path;
	public Tile endPoint;
	private Player user;
	int wave = 2;

	public Spawn(int maxEnemyCount){
		this.enemyCount = 0;
		this.maxEnemy = maxEnemyCount;
		this.enemies = new ArrayList<Enemy>(maxEnemyCount);
		this.user = null;
		this.enemyTypes = new EnemyType[4];
		this.enemyTypes[0] = EnemyType.Fire;
		this.enemyTypes[1] = EnemyType.Alien;
		this.enemyTypes[2] = EnemyType.Devil;
		this.enemyTypes[3] = EnemyType.Virus;
	}
	
	public void SpawnEnemy(Tile spawn, Tile endPoint, Tile[] path){
		this.spawn = spawn;
		this.path = path;
		Random random = new Random();
		double enemyChooser;
		if(enemyCount < maxEnemy){
			enemyChooser = random.nextInt(4);
			if(enemyChooser == 0){
				Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[0]);
				enemies.add(e);
				enemies.get(enemyCount).setIndex(enemyCount);
				System.out.println("Enemy" + enemyCount + ":" + e);
				enemyCount++;
			}
			else if(enemyChooser == 1){
				Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[1]);
				enemies.add(e);
				enemies.get(enemyCount).setIndex(enemyCount);
				System.out.println("Enemy" + enemyCount + ":" + e);
				enemyCount++;
			}else if(enemyChooser == 2){
				Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[2]);
				enemies.add(e);
				enemies.get(enemyCount).setIndex(enemyCount);
				System.out.println("Enemy" + enemyCount + ":" + e);
				enemyCount++;
			}else if(enemyChooser == 3){
				Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[3]);
				enemies.add(e);
				enemies.get(enemyCount).setIndex(enemyCount);
				System.out.println("Enemy" + enemyCount + ":" + e);
				enemyCount++;
			}
		}
	}
	
	public int getMaxEnemy(){
		return this.maxEnemy;
	}


	
	public void Reset(){
		if(enemyCount == maxEnemy){
			wave++;
			maxEnemy += 5;
		}
	}
	
	public boolean CheckIfAlive(ArrayList<Enemy> enemies){
		this.enemies = enemies;
		boolean isAlive = false;
		for(int i = 0; i < enemyCount; i++){
			if(this.enemies.get(i).isAlive() == true){
				System.out.println("isAlive" + i);
				isAlive = true;
			}
		}
		return isAlive;
	}
	
	public void setEnemies(ArrayList<Enemy> enemies){
		this.enemies = enemies;
	}
	public void Move(){
		for(int i = 0; i < enemyCount; i++){
			if(enemies.get(i).currPosition == path.length){
				enemies.get(i).die();
			}else if(enemies.get(i).getHealth() == 0){
				enemies.get(i).die();
			}
			if(enemies.get(i).isAlive() == true){
				enemies.get(i).move();
			}
		}
	}
	
	public int GetEnemyCount(){
		return enemyCount;
	}
	
	public void DrawEnemy(){
		for(int i = 0; i < enemyCount; i++){
			if(enemies.get(i).isAlive()){
			enemies.get(i).DrawEnemy();
			}
		}
	}

	public float getFirstEnemyX(){
		return enemies.get(0).getX();
	}
	public float getFirstEnemyY(){
		return enemies.get(0).getY();
	}
	public ArrayList<Enemy> getEnemyList(){
		return enemies;
	}
	
	public void setUser(Player user){
		this.user = user;
	}
	
	public int getWave(){
		return wave;
	}
	
}
