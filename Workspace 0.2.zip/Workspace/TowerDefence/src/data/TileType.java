package data;

public enum TileType {
	Path("flr6", false), Water("grass22", false), Ground("grd2", true);
	
	String texture;
	boolean build;
	
	TileType(String texture, boolean build) {
		this.texture = texture;
		this.build = build;
		
	}

}
