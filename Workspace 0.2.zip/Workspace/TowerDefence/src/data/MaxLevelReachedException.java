package data;

public class MaxLevelReachedException extends Exception {
	
	public MaxLevelReachedException(){}
	
	public MaxLevelReachedException(String message) {
		super(message);
	}

}
