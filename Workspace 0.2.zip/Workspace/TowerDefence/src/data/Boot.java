package data;

import GameObjects.*;
import helpers.Clock;

import org.lwjgl.LWJGLException;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.newdawn.slick.opengl.Texture;

import static org.lwjgl.opengl.GL11.*;
import static helpers.Artist.*;

public class Boot {
	
	public Boot() {
		
		BeginSession();
		Level level = new Level();
		level.nextLevel();
		TileGrid grid = new TileGrid(level.getMap());
		Tower tower = new Tower("Basic",grid.GetTile(7, 1), TowerType.Basic); 
		while (!Display.isCloseRequested()){
			Clock.update();
			grid.Draw();
			tower.update();
			
			Display.update();
			Display.sync(60);
			
			
		}
		Display.destroy();
	}
	
	public static void main(String[] args){
		new Boot();
	}
}
