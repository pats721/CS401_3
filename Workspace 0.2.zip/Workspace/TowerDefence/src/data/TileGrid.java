package data;

import static helpers.Artist.*;

public class TileGrid {
	
	public Tile[][] tilemap;
	
	public TileGrid() {
		tilemap = new Tile[20][15];
		for (int i = 0; i < tilemap.length; i++){
			for(int j = 0; j < tilemap[i].length; j++){
				tilemap[i][j] = new Tile(i * 64, j * 64, 64, 64, TileType.Path);
			}
		}
	}
	
	public TileGrid(int[][] newtilemap){
		tilemap = new Tile[20][15];
		for (int i = 0; i < tilemap.length; i++){
			for(int j = 0; j < tilemap[i].length; j++){
				switch(newtilemap[j][i]){
				case 0:
					tilemap[i][j] = new Tile(i * 64, j * 64, 64, 64, TileType.Water);
					break;
				case 1:
					tilemap[i][j] = new Tile(i * 64, j * 64, 64, 64, TileType.Path);
					break;
				}
					
				
			}
		}
	}
	
	public void Draw(){
		for (int i = 0; i < tilemap.length; i++){
			for(int j = 0; j < tilemap[i].length; j++){
				Tile t = tilemap[i][j];
				DrawQuadTex(t.getTexture(), t.getX(), t.getY(), t.getWidth(), t.getHight()); 
			}
		}
	}
	
	public void SetTile(int xCord, int yCord, TileType type){
		tilemap[xCord][yCord] = new Tile(xCord * 64, yCord * 64, 64, 64, type);
	}
	
	public Tile GetTile(int xCord, int yCord){
		return tilemap[xCord][yCord];
	}
	

}
