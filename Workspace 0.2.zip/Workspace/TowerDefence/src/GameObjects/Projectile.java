package GameObjects;

import org.newdawn.slick.opengl.Texture;
import static helpers.Clock.*;
import static helpers.Artist.*;

public class Projectile {
	
	private Texture texture;
	private float x, y, speed;
	private int damage;
	private boolean first = true;
	
	public Projectile(Texture texture, float x, float y, float speed, int damage){
		this.texture = texture;
		this.x = x;
		this.y = y;
		this.speed = speed;
		this.damage = damage;
	}
	
	public void update() {
		if (first) {
			first = false;
		}else {
			x += Delta() * speed;
		}
		draw();
	}
	
	public void draw() {
		DrawQuadTex(texture, x, y, 32, 32);
	}
}
