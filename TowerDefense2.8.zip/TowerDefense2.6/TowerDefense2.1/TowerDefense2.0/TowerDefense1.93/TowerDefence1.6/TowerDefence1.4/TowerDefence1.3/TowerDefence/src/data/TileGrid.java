package data;

import static helpers.Artist.*;

import java.util.Map;

import org.newdawn.slick.opengl.Texture;

import UserInterface.Button;

public class TileGrid {
	public Tile[][] tilemap;
	public Tile[] path;
	public Tile spawnPoint;
	public Tile endPoint;

	public TileGrid() {
		tilemap = new Tile[20][13];
		for (int i = 0; i < tilemap.length; i++){
			for(int j = 0; j < tilemap[i].length; j++){
				tilemap[i][j] = new Tile(i * 64, j * 64, 64, 64, TileType.Path);
			}
		}
	}
	
	//Goes through an Array of an Array of integers using a for loop inside of a for loop 
	public TileGrid(int[][] newtilemap){
		int tilemapLength = 0;
		tilemap = new Tile[20][13];
		int pathCount = 0;
		int n = 0;
		
		for (int i = 0; i < tilemap.length; i++){
			for(int j = 0; j < tilemap[i].length; j++){
				if(newtilemap[j][i]>=1){
					n++;
				}
			}		
		}
		path = new Tile[n];
		for (int i = 0; i < tilemap.length; i++){
			for(int j = 0; j < tilemap[i].length; j++){			
				if(newtilemap[j][i] == 0){ //if integer is equal to 0, TileType is Ground
					tilemap[i][j] = new Tile(i * 64, j * 64, 64, 64, TileType.Ground);
				}else if(newtilemap[j][i] >= 1){ //If integer is greater than or equal to 1 a Tile is added into an array called path in corresponding value
					tilemap[i][j] = new Tile(i * 64, j * 64, 64, 64, TileType.Path);
					tilemap[i][j].setIdNum(newtilemap[j][i]);
					if(tilemapLength == 0){ //if the Tile is the first spot in the array, that Tile is equal to spawnPoint
						spawnPoint = tilemap[i][j];
					}
					if(tilemapLength == n){ //If the Tile is the last location, that Tile is equal to endPoint
						endPoint = tilemap[i][j];
					}
					path[pathCount]= tilemap[i][j];
					path[pathCount] = tilemap[i][j];
					pathCount++;
					tilemapLength++;
				}
			}
		}
		sortPath();
	}
	
	//Sorts the path array in ascending order
	public void sortPath(){
        Tile temp;  
         for(int i=0; i < path.length; i++){  
              for(int j=1; j < path.length; j++){
                   if(path[j-1].idNum > path[j].idNum){  
                         //swap elements  
                          temp = path[j-1];  
                          path[j-1] = path[j];  
                          path[j] = temp;         
                   }       
              }  
         }
	}
	
	//Draws the graphics of all the whole array of Tile objects
	public void Draw(){
		for (int i = 0; i < tilemap.length; i++){
			for(int j = 0; j < tilemap[i].length; j++){
				if(tilemap[i][j] != null){
					Tile t = tilemap[i][j];
					DrawQuadTex(t.getTexture(), t.getX(), t.getY(), t.getWidth(), t.getHight()); 
				}else{
					System.out.println(tilemap[i][j]);
				}
			}
		}
	}
	
	public void SetTile(int xCord, int yCord, TileType type){
		tilemap[xCord][yCord] = new Tile(xCord * 64, yCord * 64, 64, 64, type);
	}
	
	public Tile GetTile(int xCord, int yCord){
		return tilemap[xCord][yCord];
	}
	
	public Tile[][] getTileMap(){
		return tilemap;
	}
	
	public Tile[] getPath(){
		return path;
	}
	
	public Tile getSpawnPoint(){
		return spawnPoint;
	}
	
	public Tile getEndPoint(){
		return endPoint;
	}
}
