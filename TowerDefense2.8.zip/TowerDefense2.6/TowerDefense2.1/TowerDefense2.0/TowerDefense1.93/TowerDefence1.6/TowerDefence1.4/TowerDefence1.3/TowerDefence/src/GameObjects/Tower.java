  
package GameObjects;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.opengl.Texture;

import java.util.ArrayList;
import java.util.Random;

import static helpers.Artist.*;
import static helpers.Clock.*;

import data.*;

public class Tower {
	final static int MAXLEVEL = 5;

	private String name;
	private int baseattack;
	private double range;
	private int level;
	private Texture texture;
	private TowerType type;
	private Tile startTile;
	private float x, y, width, hight, timeSinceLastShot, firingSpeed, angle;
	private ArrayList<Projectile> projectile;
	private ArrayList<Enemy> enemies;
	private Enemy targetEnemy;
	private int targetEnemyIndex;
	private boolean targeted;
	private boolean placed;
	private int cost;
	
	//Constructor for placing a Tower without any cost
	public Tower(String name, Tile startTile, TowerType type) {
		this.name = name;
		this.startTile = startTile;
		this.x = startTile.getX();
		this.y = startTile.getY();
		this.type = type;
		this.baseattack = type.baseattack;
		this.level = 1;
		this.texture = QuickLoad(type.texture);
		this.range = type.range;
		this.width = startTile.getWidth();
		this.hight = startTile.getHight();
		this.firingSpeed = type.fire;
		this.projectile = new ArrayList<Projectile>();
		this.enemies = null;
		this.targetEnemy = null;
		this.angle = getAngle();
		this.targeted = false;
		this.placed = true;
		this.cost = type.cost;
	}
	
	//Main Constructor that is used to not place the Tower until certain conditions are met
	public Tower(String name, TowerType type){
		this.name = name;
		this.x = Mouse.getX();
		this.y = Mouse.getY();
		this.type = type;
		this.baseattack = type.baseattack;
		this.level = 1;
		this.texture = QuickLoad(type.texture);
		this.range = type.range;
		this.width = 64;
		this.hight = 64;
		this.firingSpeed = type.fire;
		this.projectile = new ArrayList<Projectile>();
		this.enemies = null;
		this.targetEnemy = null;
		this.angle = getAngle();
		this.targeted = false;
		this.placed = false;
		this.cost = type.cost;
	}
	
	//Sets a Tower position when mouse clicks a Tile
	public void PlaceTower(Tile startTile, TowerType type){
		this.startTile = startTile;
		this.x = startTile.getX();
		this.y = startTile.getY();
		this.type = type;
		this.texture = QuickLoad(type.texture);
		this.width = startTile.getWidth();
		this.hight = startTile.getHight();
	}
	
	//Finds which Enemy for the Tower to shoot
	private Enemy getTarget() {
		Enemy closestEnemy = null;
		float closestDistance = (float) this.range;
		for (Enemy e : enemies) {
			if (inRange(e) && closestDistance > getDistance(e) && e.isAlive()) {
				closestDistance = getDistance(e);
				closestEnemy = e;
			}
		}
		if (closestEnemy != null)
			this.targeted = true;
		return closestEnemy;
	}

	//Checks if target is in range
	private boolean inRange(Enemy e) {
		float xDistance = Math.abs(e.getX() - x);
		float yDistance = Math.abs(e.getY() - y);
		if (xDistance < this.range && yDistance < this.range)
			return true;
		return false;
	}
	
	
	private float getDistance(Enemy e) {
		float xDistance = Math.abs(e.getX() - x);
		float yDistance = Math.abs(e.getY() - y);

		return xDistance + yDistance;
	}
	
	//used to find which angle to shoot which angle to shoot the Projectile by using the Math.atan2 function
	private float getAngle() {
		if (this.targetEnemy != null) {
			double tempAngle = Math.atan2(targetEnemy.getY() - y, targetEnemy.getX() - x);
			return (float) Math.toDegrees(tempAngle) - 90;
		}
		return 0f;
	}
	
	//Shoots the Projectile
	private void shoot() {
		if (this.targetEnemy != null && this.targetEnemy.isAlive() == true) {
			if (inRange(this.targetEnemy)) {
				timeSinceLastShot = 0;
				//Checks which type the TowerType is to decide which Projectile to shoot
				if (this.type == TowerType.BasicSquirt) {
					projectile.add(
							new Projectile(x + 32, y + 32, 32, 32, 100, this.baseattack, this.targetEnemy, ProjectileType.Squirt));
				}
				if (this.type == TowerType.MediumSatellite) {
					projectile.add(
							new Projectile(x + 32, y + 32, 32, 32, 100, this.baseattack, this.targetEnemy, ProjectileType.Lightning));
				}
				if (this.type == TowerType.HighVolcano) {
					projectile.add(
							new Projectile(x + 32, y + 32, 32, 32, 100, this.baseattack, this.targetEnemy, ProjectileType.Volcono));
				}
			}
		}
	}

	public void updateEnemyList(ArrayList<Enemy> newList) {
		enemies = newList;
	}

	public void update() {
		this.targetEnemy = getTarget();
		if (this.targetEnemy == null || this.targetEnemy.isAlive() == false){
			this.targeted = false;
		}
		timeSinceLastShot += Delta();
		if (timeSinceLastShot > firingSpeed){
			shoot();
		}
		for (Projectile p : projectile){
			p.update();
			if(p.isAlive() != true){
				for(int i = 0; i < enemies.size(); i++){
					if(p.getTargetIndex() == i){
						enemies.remove(i);
						enemies.add(i, p.getTarget());
					}
				}
			}
		}
		this.angle = getAngle();
	}

	//Draws the graphics for the Tower
	public void DrawTower() {
		DrawQuadTex(this.texture, this.x, this.y, this.width, this.hight);
	}
	
	//Used for moving the Tower to the Mouse position when the Tower is being held by the Player class
	public void MoveTower(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	//Sets the Tower when the Player places it on a Tile
	public void SetTower(Tile startTile){
		this.startTile = startTile;
		this.x = startTile.getX();
		this.y = startTile.getY();
		this.placed = true;
	}
	
	public boolean isPlaced(){
		return this.placed;
	}

	public double getRange() {
		return range;
	}
	
	public float getTargetHealth(){
		return this.targetEnemy.getHealth();
	}
	
	public ArrayList<Enemy> getEnemies(){
		return this.enemies;
	}
	
	public float getX(){
		return this.x;
	}
	public float getY(){
		return this.y;
	}
	
	public int getCost(){
		return this.cost;
	}
}