package GameObjects;

import org.newdawn.slick.opengl.Texture;

import data.Enemy;
import data.EnemyType;

import static helpers.Clock.*;

import java.util.ArrayList;

import static helpers.Artist.*;

public class Projectile {

	private Texture texture;
	private float x, y, width, hight, speed, xSpeed, ySpeed;
	private int damage;
	private boolean first = false;
	private Enemy target;
	private int targetIndex;
	private boolean alive;
	private ProjectileType type;
	
	public Projectile(float x, float y, float width, float hight, float speed, int damage,
			Enemy target, ProjectileType type) {
		this.texture = QuickLoad(type.texture);
		this.x = x;
		this.y = y;
		this.speed = speed;
		this.damage = damage;
		this.target = target;
		this.targetIndex = target.getIndex();
		this.xSpeed = 0f;
		this.ySpeed = 0f;
		this.alive = true;
		this.width = width;
		this.hight = hight;
		this.type = type;
		aim();
	}

	private void aim() {
		if (this.target != null && this.target.isAlive() == true) {
			float totalAllowedMovement = 1.0f;
			float xDistance = Math.abs(target.getX() - x);
			float yDistance = Math.abs(target.getY() - y);
			float totalDistance = xDistance + yDistance;
			float xPercentofMovement = xDistance / totalDistance;

			this.xSpeed = xPercentofMovement;
			this.ySpeed = totalAllowedMovement - xPercentofMovement;

			if (target.getX() < x)
				this.xSpeed *= -1;
			if (target.getY() < y)
				this.ySpeed *= -1;
		}
	}

	public void update() {
		if (this.target != null && this.target.isAlive() == true) {
			if (alive) {
				x += this.xSpeed * speed * Delta();
				y += this.ySpeed * speed * Delta();
				if (CheckCollision(x, y, width, hight, target.getX(), target.getY(), target.getWidth(),
						target.getHight())){
					this.alive = false;
					if(this.type == ProjectileType.Volcono && target.getType() != EnemyType.Poop){
						target.setMoveSpd(.5f);
					}
					target.setHealth(this.damage);
				}
				draw();
			}
		}
	}
	public boolean isAlive(){
		return this.alive;
	}
	
	public void draw() {
		DrawQuadTex(texture, x, y, 32, 32);
	}
	
	public Enemy getTarget(){
		return this.target;
	}
	
	public int getTargetIndex(){
		return this.targetIndex;
	}
}