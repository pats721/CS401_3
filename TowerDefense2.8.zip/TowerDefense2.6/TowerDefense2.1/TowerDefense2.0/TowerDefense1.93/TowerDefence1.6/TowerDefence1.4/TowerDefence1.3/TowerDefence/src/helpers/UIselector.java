package helpers;

import data.MainMenu;
import GameObjects.Level;
import data.GameMenu;
import helpers.Artist.*;

public class UIselector {
	
	public static boolean isPlaying = false;
	public static boolean createGame = false;
	public static enum UIState {
		MAINMENU, LEVEL
	}
	public static UIState uiState = UIState.MAINMENU;
	public static MainMenu mainMenu = new MainMenu();
	public static GameMenu gameMenu = new GameMenu();
	public static Level level;
	
	public static void update() {
		
		//Switch case for the MAINMENU and LEVEL states  
		switch(uiState) {
		
		case MAINMENU:
			mainMenu.update();
			break;
	
		case LEVEL:
			gameMenu.update();
			isPlaying = true;
			break;
		}
	}
	
	public static void setUI(UIState newUI) {
		uiState = newUI;
	}
	
	public static void setMainMenu(){
		uiState = UIState.MAINMENU;
		isPlaying = false;
	}
	
	//Used to make sure the CreateGame class is not updating
	public static boolean isPlaying(){
		if(isPlaying){
			return true;
		}else{
			return false;
		}
	}
	
	public static GameMenu getGameMenu(){
		return gameMenu;
	}
}
