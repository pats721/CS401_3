package data;

public enum TileType {
	Path("brick1", true), Water("grass64", false), Ground("grd2", true), TowerSpace("ant11", true);
	
	String texture;
	boolean build;
	
	TileType(String texture, boolean build) {
		this.texture = texture;
		this.build = build;
		
	}

}
