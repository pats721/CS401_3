package data;

public enum EnemyType {
	Robot("robot64", true, 140, 2, 1, 10), Alien("Alien64", true, 300, 1, 1, 20), Virus("virus64", true, 225, 4, 1, 30), Poop("poop", true, 2700, 1, 3, 100), Devil("devil64", true, 270, 1, 3, 100);;
	
	String texture;
	boolean build;
	int health;
	float moveSpeed;
	int dmg;
	int score;
	EnemyType(String texture, boolean build, int health, float moveSpeed, int dmg, int score){
		this.texture = texture;
		this.build = build;
		this.health = health;
		this.moveSpeed = moveSpeed;
		this.dmg = dmg;
		this.score = score;
	}
}

