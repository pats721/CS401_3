package data;

import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.LWJGLException;
import org.newdawn.slick.opengl.Texture;

import helpers.UIselector;

import static org.lwjgl.opengl.GL11.*;
import static helpers.Artist.*;



public class Boot {
	
	private static final int GL_PROTECTION = 0;

	public Boot() {
		
/*		Display.setTitle("Tower Defense");
		try {
			Display.setDisplayMode(new DisplayMode(700,500));
			Display.create();
		} catch (LWJGLException e) {
			e.printStackTrace();
		}
		*/

		BeginSession();
		
		//Level level = new Level();
		//level.nextLevel();
		//TileGrid grid = new TileGrid(level.getMap());
		
		while (!Display.isCloseRequested()){
			
			UIselector.update();
			
			//grid.Draw();
			
			Display.update();
			Display.sync(60);
			
			
		}
		Display.destroy();
	}
	
	public static void main(String[] args){
		new Boot();
	}
}
