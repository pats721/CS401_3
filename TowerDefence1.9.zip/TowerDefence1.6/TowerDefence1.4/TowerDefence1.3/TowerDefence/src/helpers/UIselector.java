package helpers;

import data.Level;
import data.MainMenu;
import data.GameMenu;
import helpers.Artist.*;

public class UIselector {
	
	public static boolean isPlaying = false;
	public static boolean createGame = false;
	public static enum UIState {
		MAINMENU, LEVEL
	}
	public static UIState uiState = UIState.MAINMENU;
	public static MainMenu mainMenu = new MainMenu();
	public static GameMenu gameMenu = new GameMenu();
	public static Level level;
	
	public static void update() {
		
		switch(uiState) {
		
		case MAINMENU:
		//	if (mainMenu == null)
			//	mainMenu = new MainMenu();
			mainMenu.update();
			break;
	
		case LEVEL:
		//	if (gameMenu == null)
			//	gameMenu = new GameMenu();
			gameMenu.update();
			isPlaying = true;
			break;
			
		}
	}
	
	public static void setUI(UIState newUI) {
		uiState = newUI;
		
	}
	public static void setMainMenu(){
		uiState = UIState.MAINMENU;
		isPlaying = false;
	}
	public static boolean isPlaying(){
		if(isPlaying){
			return true;
		}else{
			return false;
		}
	}
	public static GameMenu getGameMenu(){
		return gameMenu;
	}
}
