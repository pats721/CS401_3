package data;

import java.util.ArrayList;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Clock;
import helpers.UIselector;
import helpers.UIselector.UIState;

public class CreateGame {
	GameHandler game;
	public CreateGame(){
		this.game = new GameHandler();
	}
	
	public void update(){
		if(game.paused()){
			UIselector.update();
			game.DrawGrid();
			//game.updateGameMenu();
			game.DrawEnemy();
			game.DrawTower();
		}
		if(!game.paused()){
			UIselector.update();
		if(UIselector.uiState == UIState.LEVEL){
			Clock.update();
				game.DrawGrid();
				//game.updateGameMenu();
				if(!game.CheckIfAlive()){
				game.UpdateEnemy();
				game.Movement();
				game.DrawEnemy();
				}
				game.UpdateTower();
				game.DrawTower();
				if(game.CheckIfAlive()){
					game.nextWave();
				}/*
				if(game.isEnd()){
					game.newGame();
				}*/
			}
		}
	}
}