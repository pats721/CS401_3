package data;

import org.lwjgl.Sys;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.Color;
import org.newdawn.slick.TrueTypeFont;
import org.newdawn.slick.util.ResourceLoader;

import GameObjects.Tower;
import helpers.Clock;
import helpers.UIselector;

import static helpers.Artist.HEIGHT;
import static helpers.Clock.*;
import static helpers.UIselector.*;
import java.awt.Font;
import java.io.InputStream;
import java.util.ArrayList;

public class GameHandler {
	Tile[] path;
	Tile[][] map;
	TileGrid grid;
	Spawn spawner;
	Tile spawnPoint;
	Tile endPoint;
	Player user;
	public int maxEnemyCount;
	public int enemyCount;
	public float timeSinceLastSpawn = 0;
	private float timeSinceLastWave = 0;
	public int spawnSpeed = 20;
	public Level currLevel;
	public boolean enemiesAlive = true;
	private Tower t;
	private ArrayList<Tower> towerList;
	private ArrayList<Enemy> enemies;
	private GameMenu ui;
	private int score = 0;
	private int lives = 1;
	
	private int money = 100;
	private int currTowerPos = 0;
	private boolean leftMouseButtonDown = false;
	
	public GameHandler(){	
		this.currLevel = new Level();
		this.currLevel.nextLevel();
		this.spawner = new Spawn(currLevel.getMaxEnemy());
		this.grid = new TileGrid(currLevel.getMap());
		this.map = grid.getTileMap();
		this.path = grid.getPath();
		this.maxEnemyCount = currLevel.getMaxEnemy();
		this.enemyCount = 0;
		this.spawnPoint = grid.getSpawnPoint();
		this.endPoint = grid.getEndPoint();
		this.enemies = spawner.getEnemyList();
		this.ui = UIselector.getGameMenu();
		this.user = new Player(this.grid, this.enemies, this.ui);
		this.towerList = user.getTowerList();
	}
	
	public boolean paused(){
		boolean paused = this.user.paused();
		if(paused && !Clock.isPaused()){
			Clock.Pause();
		}else if(!paused && Clock.isPaused()){
			Clock.Pause();
		}
		return paused;
	}
	
	public void newGame(){
		
	}
	
	public boolean isEnd(){
		if(this.lives <= 0){
			return true;
		}return false;
	}
	
	public void updateGameMenu(){
		ui.drawHealth(String.valueOf(lives));
		ui.drawText(String.valueOf(money), String.valueOf(score));
		ui.update();
		
	}
	
	public void nextWave(){
		this.timeSinceLastWave += Delta();
		if(timeSinceLastWave > 300){
			timeSinceLastWave = 0;
			this.spawner = new Spawn(currLevel.getMaxEnemy());
			enemies = spawner.getEnemyList();
			Spawn();
			
		}
	}
	
	public void DrawGrid(){
		grid.Draw();
	}
	
	public void UpdateEnemy(){
		timeSinceLastSpawn += Delta();
		System.out.println(timeSinceLastSpawn);
		if(timeSinceLastSpawn > spawnSpeed){
			Spawn();
			this.enemies = spawner.getEnemyList();
		}
		LifeUpdate();
		Scoring();
	}
	
	public void LifeUpdate(){
		for(Enemy e: enemies){
			if(e.getCurrPosition() == path.length){
				if(!e.getAttacked())
				this.lives = this.lives - e.attackBase();
			}
		}
	}
	
	public void UpdateTower(){
		user.update(this.towerList);
		this.towerList = user.getTowerList();
		if(user.isHolding())
		user.getTowerList().get(user.getHolding()).MoveTower(Mouse.getX(), 1024 - Mouse.getY());
		for(Tower t: towerList){
			t.updateEnemyList(this.enemies);
			t.update();
			this.enemies = t.getEnemies();
			DestroyEnemies();
		}
	}
	
	public void DrawTower(){
		for(Tower t: towerList){
			t.DrawTower();
		}
	}
	
	public void DestroyEnemies(){
		ArrayList<Enemy> locEnemies = this.enemies;
		int locEnemyCount=0;
			for(Enemy e: enemies){
				if(e.getHealth() <= 0){
					locEnemies.get(e.getIndex()).die();
				}
				locEnemyCount++;
			}this.enemies = locEnemies;
	}
	
	public void Scoring(){
		for(Enemy e: enemies){
			if(!e.isAlive() && !e.getGotPoints()){
				this.score += 10;
				this.money += 5;
				e.gotPoints();
				
			}
		}
		
	}
	
	public boolean CheckIfAlive(){
		if(spawner.CheckIfAlive() == true){
			return true;
		}
		if(this.lives <= 0){
			return true;
		}
		return false;
	}
	
	public void Spawn(){
		timeSinceLastSpawn = 0;
		spawner.SpawnEnemy(spawnPoint, endPoint, path);
	}
	public void DrawEnemy(){
		spawner.DrawEnemy();
	}
	public void Movement(){
		spawner.Move();
	}
	public float GetEnemyX(){
		return spawner.getFirstEnemyX();
	}
	
	public float GetEnemyY(){
		return spawner.getFirstEnemyY();
	}
	
	public Spawn GetSpawner() {
		return this.spawner;
	}
}
