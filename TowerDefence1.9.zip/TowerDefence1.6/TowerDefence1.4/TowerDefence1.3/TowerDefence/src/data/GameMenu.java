package data;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.Color;
import org.newdawn.slick.TrueTypeFont;
import org.newdawn.slick.opengl.Texture;
import UserInterface.*;
import helpers.UIselector;
import helpers.UIselector.UIState;
import static helpers.Artist.*;
import java.awt.Font;
import org.lwjgl.input.Mouse;

import UserInterface.UserInterface;

public class GameMenu {
	private Texture background;
	private UserInterface gameMenu;
	private TrueTypeFont font;
	private Font awtFont;
	private Text text = new Text();
	public GameMenu() {
		gameMenu = new UserInterface();
		background = QuickLoad("gmbg");
		gameMenu.addButton("Volcano", "volcano64", 0, 964);
		gameMenu.addButton("SquirtGun", "gun64", 0, 900);
		awtFont = new Font("Times New Roman", Font.BOLD, 48);
		font = new TrueTypeFont(awtFont, true);
		
	}

	public int updateButtons() {
		if(Mouse.isButtonDown(0)){
			if (gameMenu.isButtonClicked("Volcano"))
				return 2;
				//System.out.println("Play button clicked");
			if (gameMenu.isButtonClicked("SquirtGun"))
				return 0;
			if (gameMenu.isButtonClicked("SquirtGun"))
				return 1;
		}return 100;
	}
	
	
	public void update() {
		DrawQuadTex(background, 0, 896, 2048, 2048);
		gameMenu.Draw();
		updateButtons();
	}
	
	public void drawHealth(String lives){
		text.drawString(lives, 650, 1140);
	}
	
	public void drawText(String money, String score){
		text.drawString(score, 1050, 1140);
		text.drawString(money, 820, 1140);
	}
	
}

