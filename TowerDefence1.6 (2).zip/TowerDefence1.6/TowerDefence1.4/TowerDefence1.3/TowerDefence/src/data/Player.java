package data;

import java.util.ArrayList;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import static helpers.Artist.*;

import GameObjects.Tower;
import GameObjects.TowerType;
import UserInterface.UserInterface;

public class Player {

	private TileGrid grid;
	private TileType[] types;
	private TowerType[] towertypes;
	private int index;
	private ArrayList<Tower> towerList;
	private boolean leftMouseButtonDown = true;
	private boolean rightMouseButtonDown = true;
	private boolean keyPisDown = true;
	private boolean gamePaused = false;
	private int holding;
	private GameMenu ui;
	public Player(TileGrid grid, ArrayList<Enemy> enemies, GameMenu ui ) {
		this.grid = grid;
		this.types = new TileType[3];
		this.towertypes = new TowerType[3];
		this.index = 0;
		this.towerList = new ArrayList<Tower>();
		this.types[0] = TileType.Path;
		this.types[1] = TileType.Water;
		this.types[2] = TileType.Ground;
		this.towertypes[0] = TowerType.BasicSquirt;
		this.towertypes[1] = TowerType.MediumSatellite;
		this.towertypes[2] = TowerType.HighVolcano;
		this.ui = ui;	
	}

	public void setTile() {
		grid.SetTile((int) Math.floor(Mouse.getX() / 64), (int) Math.floor((HEIGHT - Mouse.getY() - 1) / 64),
				types[index]);
	}

	public void update() {
			// Mouse Input.
			if((Mouse.isButtonDown(0) && !leftMouseButtonDown)){	
					if(grid.GetTile((int) Math.floor(Mouse.getX() / 64),(int) Math.floor((HEIGHT - Mouse.getY() - 1)/64)).getType() == types[1] && grid.GetTile((int) Math.floor(Mouse.getX() / 64),(int) Math.floor((HEIGHT - Mouse.getY() - 1)/64)).getOccupance() == false){
						towerList.add(new Tower("fkghhg", grid.GetTile((int) Math.floor(Mouse.getX() / 64), (int) Math.floor((HEIGHT - Mouse.getY() - 1) / 64)), towertypes[index]));
						grid.GetTile((int) Math.floor(Mouse.getX() / 64),(int) Math.floor((HEIGHT - Mouse.getY() - 1)/64)).setOccupance(true);
					}
				} leftMouseButtonDown = Mouse.isButtonDown(0);
				if (Mouse.isButtonDown(1) && !rightMouseButtonDown) {
						if(grid.GetTile((int) Math.floor(Mouse.getX() / 64),(int) Math.floor((HEIGHT - Mouse.getY() - 1)/64)).getType() == types[1] && grid.GetTile((int) Math.floor(Mouse.getX() / 64),(int) Math.floor((HEIGHT - Mouse.getY() - 1)/64)).getOccupance() == false){
							towerList.add(new Tower("fkghhh", grid.GetTile((int) Math.floor(Mouse.getX() / 64), (int) Math.floor((HEIGHT - Mouse.getY() - 1) / 64)), TowerType.HighVolcano));
							grid.GetTile((int) Math.floor(Mouse.getX() / 64),(int) Math.floor((HEIGHT - Mouse.getY() - 1)/64)).setOccupance(true);
						}
					}
				rightMouseButtonDown = Mouse.isButtonDown(1);
	
			// Keyboard Input.
			while (Keyboard.next()) {
				if (Keyboard.getEventKey() == Keyboard.KEY_RIGHT && Keyboard.getEventKeyState()) {
					moveIndex();
				}
				if (Keyboard.getEventKey() == Keyboard.KEY_RIGHT && Keyboard.getEventKeyState()) {
					moveIndex();
				}
				if (Keyboard.getEventKey() == Keyboard.KEY_T && Keyboard.getEventKeyState()) {
					towerList.add(new Tower("fkghhg", grid.GetTile(18, 9), TowerType.BasicSquirt));
				}
			}
	}
	public boolean paused(){
		if(Keyboard.isKeyDown(Keyboard.KEY_P) && !keyPisDown) {
		    gamePaused = !gamePaused;
		}keyPisDown = Keyboard.isKeyDown(Keyboard.KEY_P);
		return gamePaused;
	}
	private void moveIndex() {
		index++;
		if (index > types.length - 1) {
			index = 0;
		}
	}

	public ArrayList<Tower> getTowerList() {
		return towerList;
	}

	public void setTowerList(ArrayList<Tower> towerList) {
		this.towerList = towerList;
	}
}