package data;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.Color;
import org.newdawn.slick.TrueTypeFont;
import org.newdawn.slick.opengl.Texture;
import UserInterface.*;
import helpers.UIselector;
import helpers.UIselector.UIState;
import static helpers.Artist.*;
import java.awt.Font;
import org.lwjgl.input.Mouse;

import UserInterface.UserInterface;

public class GameMenu {
	private Texture background;
	private UserInterface gameMenu;
	private TrueTypeFont font;
	private Font awtFont;
	private Text text;
	public GameMenu() {
		gameMenu = new UserInterface();
		gameMenu.addButton("SquirtGun", "gun64", 0, 900);
		gameMenu.addButton("Satellite", "satellite64", 256, 900);
		gameMenu.addButton("Volcano", "volcano64", 128, 900);
		gameMenu.addButton("House", "House64", 1205, 445);
	}

	public int updateButtons() {
		if(Mouse.isButtonDown(0)){
			if (gameMenu.isButtonClicked("SquirtGun"))
				return 0;
			if (gameMenu.isButtonClicked("Satellite"))
				return 1;
			if (gameMenu.isButtonClicked("Volcano"))
				return 2;
		}return 100;
	}
	
	
	public void update() {
		gameMenu.Draw();
		updateButtons();
	}
	
}
