package GameObjects;

public enum TowerType {
	BasicSquirt("gun64", 250, 5, 3, 20, 25, 8, 40), MediumSatellite("satellite64", 700, 5, 3, 8, 15, 3, 110), HighVolcano("volcano64", 150, 5, 5, 30, 40, 10, 60);
	
	String texture;
	double range;
	int tcost;
	int upcost;
	int baseattack;
	int maxattack;
	float fire;
	int cost;
	
	TowerType(String texture, double range, int tcost, int upcost, int baseattack, int maxattack, float fire, int cost) {
		this.texture = texture;
		this.range = range;
		this.tcost = tcost;
		this.upcost = upcost;
		this.baseattack = baseattack;
		this.maxattack = maxattack;
		this.fire = fire;
		this.cost = cost;
	}
}