package data;

public enum EnemyType {
	Fire("Fire32", true, 50, 2, 1), Alien("Alien64", true, 80, 1, 1), Virus("virus64", true, 30, 4, 1), Devil("devil64", true, 200, .5f, 5);
	
	String texture;
	boolean build;
	int health;
	float moveSpeed;
	int dmg;
	
	EnemyType(String texture, boolean build, int health, float moveSpeed, int dmg){
		this.texture = texture;
		this.build = build;
		this.health = health;
		this.moveSpeed = moveSpeed;
		this.dmg = dmg;
	}
}

