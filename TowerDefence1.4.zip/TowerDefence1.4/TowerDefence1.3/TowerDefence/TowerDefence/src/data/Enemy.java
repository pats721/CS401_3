package data;
import static helpers.Artist.*;
import org.newdawn.slick.opengl.Texture;

import helpers.Artist;
public class Enemy {
	Texture water = QuickLoad("wtr3");
	
	float x;
	float y;
	float width;
	float hight;
	Tile target;
	Tile[] path;
	public boolean isSpawned = false;
	public boolean alive = true;
	public int currPosition = 1;
	public final float moveSpeed = 4;
	public Tile endPoint;
	
	public Enemy(Tile spawn, Tile endPoint, Tile[] path){
		this.x = spawn.getX();
		this.y = spawn.getY();
		this.width = spawn.getWidth();
		this.hight = spawn.getHight();
		this.path = path;
		this.endPoint = endPoint;
		DrawQuadTex(this.water, x, y, width, hight);
	}
	
	public void move(){
			if(this.x < this.path[currPosition].getX()){
				this.x = this.x + moveSpeed;
				if(this.y < this.path[currPosition].getY()){	
						this.y = this.y + moveSpeed;
					}
					else if(this.y > this.path[currPosition].getY()){
						this.y = this.y - moveSpeed;
					}
				}
				else if(this.x > this.path[currPosition].getX()){
					this.x = this.x - moveSpeed;
					if(this.y < this.path[currPosition].getY()){
						this.y = this.y + moveSpeed;
					}
					else if(this.y > this.path[currPosition].getY()){
						this.y = this.y - moveSpeed;
					}
				}
				else{
					if(this.y < this.path[currPosition].getY()){
						this.y = this.y + moveSpeed;
					}
					else if(this.y > this.path[currPosition].getY()){
						this.y = this.y - moveSpeed;
					}else{
						currPosition++;
				}
			}
		}
	public void DrawEnemy(){
		DrawQuadTex(this.water, x, y, width, hight);
	}
	public Tile GetTarget(){
		return this.target;
	}
	
	public void SetTarget(Tile target){
		 this.target = target;
	}
	
	public void setX(int x){
		this.x = x;
	}
	
	public void setY(int y){
		this.y = y;
	}
	
	public float getX(){
		return this.x;
	}
	
	public float getY(){
		return this.y;
	}
	
	public int getCurrPosition(){
		return currPosition;
	}
	
	public boolean isAlive(){
		return alive;
	}
	
	public void die(){
		this.alive = false;
		
	}
}
