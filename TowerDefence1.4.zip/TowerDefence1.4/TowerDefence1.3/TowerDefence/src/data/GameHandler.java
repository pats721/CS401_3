package data;

import org.lwjgl.Sys;

import GameObjects.Tower;

import static helpers.Clock.*;

import java.util.ArrayList;

public class GameHandler {
	Tile[] path;
	Tile[][] map;
	Spawn spawner;
	WaveController waveCont;
	Tile spawnPoint;
	Tile endPoint;
	public int maxEnemyCount;
	public int enemyCount;
	public float timeSinceLastSpawn = 0;
	public int spawnSpeed = 20;
	public Level currLevel;
	public boolean enemiesAlive = true;
	private Player user;
	private Tower t;
	private ArrayList<Tower> towerList;
	private ArrayList<Enemy> enemies;
	
	public GameHandler(Tile[] path, Tile[][] map, Spawn spawner, Tile spawnPoint, Tile endPoint, Level currLevel, Player user){
		this.path = path;
		this.map = map;
		this.spawner = spawner;
		this.spawner.setUser(this.user);
		this.maxEnemyCount = spawner.GetEnemyCount();
		this.enemyCount = 0;
		this.spawnPoint = spawnPoint;
		this.endPoint = endPoint;
		this.waveCont = new WaveController(currLevel, spawner);
		this.user = user;
		this.towerList = user.getTowerList();
		Spawn();
	}

	public void UpdateEnemy(){
		timeSinceLastSpawn += Delta();
		System.out.println(timeSinceLastSpawn);
		if(timeSinceLastSpawn > spawnSpeed){
			Spawn();
		}
	}
	
	public void UpdateTower(){
		user.update(this.enemies);
		this.towerList = user.getTowerList();
		for(Tower t: towerList){
			
		}
	}
	
	public void DestroyEnemies(){
		ArrayList<Enemy> locEnemies = this.enemies;
		int locEnemyCount=0;
			for(Enemy e: t.getEnemies()){
				if(e.getHealth() == 0){
					locEnemies.get(e.getIndex()).die();
				}
				locEnemyCount++;
			}this.enemies = locEnemies;
		}
	
	public void CheckIfAlive(){
		DestroyEnemies();
		spawner.CheckIfAlive();
	}
	
	public void Spawn(){
		timeSinceLastSpawn = 0;
			spawner.SpawnEnemy(spawnPoint, endPoint, path);
	}
	
	public void Movement(){
		spawner.Move();
		spawner.DrawEnemy();
	}
	public float GetEnemyX(){
		return spawner.getFirstEnemyX();
	}
	
	public float GetEnemyY(){
		return spawner.getFirstEnemyY();
	}
	
	public Spawn GetSpawner() {
		return this.spawner;
	}
	
	public void addTower(Tower t){
		towerList.add(t);
	}
}
