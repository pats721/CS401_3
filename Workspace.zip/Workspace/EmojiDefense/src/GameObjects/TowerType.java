package GameObjects;

public enum TowerType {
	BasicSquirt("gun64", 250, 5, 3, 30, 25, 7, 30), MediumSatellite("satellite64", 700, 5, 3, 12, 15, 5, 110), HighVolcano("volcano64", 200, 5, 5, 30, 100, 8, 60);
	
	String texture;
	double range;
	int tcost;
	int upcost;
	int baseattack;
	int maxattack;
	float fire;
	int cost;
	
	TowerType(String texture, double range, int tcost, int upcost, int baseattack, int maxattack, float fire, int cost) {
		this.texture = texture;
		this.range = range;
		this.tcost = tcost;
		this.upcost = upcost;
		this.baseattack = baseattack;
		this.maxattack = maxattack;
		this.fire = fire;
		this.cost = cost;
	}
}