package data;

import org.lwjgl.input.Mouse;
import org.newdawn.slick.opengl.Texture;
import UserInterface.*;
import helpers.UIselector;
import helpers.UIselector.UIState;

import static helpers.Artist.*;

public class MainMenu {
	
	private Texture background;
	private UserInterface mainMenu;
	
	//Initializes the first screen when booting the program
	public MainMenu() {
		background = QuickLoad("Bg2");
		mainMenu = new UserInterface();
		mainMenu.addButton("StartGame", "PlayButton3", WIDTH / 2 - 128, (int) (HEIGHT * 0.45f));
		mainMenu.addButton("QuitGame", "QuitButton2", WIDTH / 2 - 128, (int) (HEIGHT * 0.55f));
		mainMenu.addButton("HighScores", "HighScores", WIDTH / 2 - 128, (int) (HEIGHT * 0.65f));
	}
	
	//Checks to see which button is clicked, and switches the GameState bassed off of which button is clicked
	private void updateButtons() {
		if (Mouse.isButtonDown(0)) {
			if (mainMenu.isButtonClicked("StartGame"))
				UIselector.setUI(UIState.LEVEL);
			
			else if (mainMenu.isButtonClicked("QuitGame"))
				System.exit(0);
		}
	}
	
	//Draws the graphics of the Main Menu
	public void update() {
		DrawQuadTex(background, 0, 0, 2048, 1024);
		mainMenu.Draw();
		updateButtons();
	}
}
