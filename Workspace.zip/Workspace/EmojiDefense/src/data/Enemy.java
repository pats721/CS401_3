package data;
import static helpers.Artist.*;
import static helpers.Clock.*;
import org.newdawn.slick.opengl.Texture;

import helpers.Artist;
public class Enemy {
	
	private static final float TILE_SIZE = 64;
	Texture texture;
	EnemyType type;
	private Texture backHealth, frontHealth, healthOutline; 
	float x;
	float y;
	float width;
	float hight;
	Tile target;
	Tile[] path;
	public boolean isSpawned = false;
	public boolean alive = true;
	public int currPosition = 1;
	public int maxPosition;
	public float moveSpeed, baseSpeed;
	public Tile endPoint;
	private float health, healthStart;
	private int dmg;
	private int index;
	private boolean gotPoints = false;
	private boolean attacked = false;
	private int score;
	private boolean tagged = false;
	private int taggedIndex;
	
	public Enemy(Tile spawn, Tile endPoint, Tile[] path, EnemyType type){
		this.backHealth = QuickLoad ("backHealth");
		this.frontHealth = QuickLoad ("frontHealth");
		this.healthOutline = QuickLoad ("healthOutline");
		this.x = spawn.getX();
		this.y = spawn.getY();
		this.width = spawn.getWidth();
		this.hight = spawn.getHight();
		this.path = path;
		this.endPoint = endPoint;
		this.index = 0;
		this.health = type.health;
		this.dmg = type.dmg;
		this.moveSpeed = type.moveSpeed;
		this.baseSpeed = type.moveSpeed;
		this.healthStart = health;
		this.type = type;
		this.texture = QuickLoad(type.texture);
		this.score = type.score;
		this.maxPosition = path.length;
	}
	
	/*Moves Enemy based off of it's x and y position
	  compared to the next path's x and y position.
	  When Enemy x and y position is equal to the 
	  next path's x and y position; it adds one to
	   Enemy's currPosition */
	public void move(){
		if(this.x < this.path[currPosition].getX()){
			this.x = this.x + moveSpeed;
			if(this.y < this.path[currPosition].getY()){	
					this.y = this.y + moveSpeed;
				}
				else if(this.y > this.path[currPosition].getY()){
					this.y = this.y - moveSpeed;
				}
		}else if(this.x > this.path[currPosition].getX()){
			this.x = this.x - moveSpeed;
			if(this.y < this.path[currPosition].getY()){
				this.y = this.y + moveSpeed;
			}
			else if(this.y > this.path[currPosition].getY()){
				this.y = this.y - moveSpeed;
			}
		}else{
			if(this.y < this.path[currPosition].getY()){
				this.y = this.y + moveSpeed;
			}
			else if(this.y > this.path[currPosition].getY()){
				this.y = this.y - moveSpeed;
			}else{
				currPosition++;
			}
		}
	}
	
	//Draws graphics for Enemy and Health bar above the Enemy
	public void DrawEnemy(){
		float healthTotal = health / healthStart;
		DrawQuadTex(texture, x, y, width, hight);
		DrawQuadTex(backHealth, x, y - 14, width, 7);
		DrawQuadTex(frontHealth, x, y - 14, TILE_SIZE * healthTotal, 7);
		DrawQuadTex(healthOutline, x, y - 14, width, 7);
	}
	
	public float getX(){
		return this.x;
	}
	
	public float getY(){
		return this.y;
	}
	
	public int getCurrPosition(){
		return currPosition;
	}
	
	//When Enemy spawns sets isSpawned to true
	public void isSpawned(){
		this.isSpawned = true;
	}
	
	public boolean getIsSpawned(){
		return this.isSpawned;
	}
	
	public boolean isAlive(){
		return alive;
	}
	
	//When alive is set to false the Enemy stops updating and drawing graphics
	public void die(){
		this.alive = false;
	}
	
	public void alive(){
		this.alive = true;
	}
	
	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public float getHight() {
		return hight;
	}

	public void setHight(float hight) {
		this.hight = hight;
	}
	
	//Every time a Projectile collides with an Enemy the health is subtracted by dmg
	public void setHealth(int dmg){
		this.health -= dmg;
	}
	
	//Sets health manually so both the health and healthStart are set to a certain amount
	public void setBaseHealth(int health){
		this.healthStart = health;
		this.health = health;
	}
	
	public float getHealth(){
		return this.health;
	}
	
	//Sets the movement speed to implement the Tower functionality to slow down the moveSpeed
	//of any Enemy hit
	public void setMoveSpd(float mult){
		if(tagged == false){ //Checks to see if the Enemy has already been hit
			this.moveSpeed = baseSpeed * mult;
			this.taggedIndex = currPosition;
			this.tagged = true;
		}
		if(mult == 0){ //Resets moveSpeed
			this.moveSpeed = baseSpeed;
			this.tagged = false;
		}
	}
	
	//Resets moveSpeed of Enemy to baseSpeed after 5 tiles have been reached
	public void MoveSpeedDuration(){
		if(this.tagged){
			if(taggedIndex+5 == currPosition){
				setMoveSpd(0);
			}
		}
	}
	
	//Sets to true so GameHandler does not receive points from the same Enemy more than once
	public void gotPoints(){
		this.gotPoints = true;
	}
	
	public boolean getGotPoints(){
		return this.gotPoints;
	}
	
	//Used to calculate the subtraction from the GameHandler lives value
	public int attackBase(){
		this.attacked = true;
		return this.dmg;
	}
	
	public boolean getAttacked(){
		return this.attacked;
	}
	
	public int getScore(){
		return this.score;
	}
	
	//Assigns a number value in ascending order to Enemy when it is constructed
	public void setIndex(int index){
		this.index = index;
	}
	
	public int getIndex(){
		return this.index;
	}
	
	public float getBaseSpeed(){
		return this.baseSpeed;
	}
	
	public float getMoveSpeed(){
		return this.moveSpeed;
	}
	
	public EnemyType getType(){
		return this.type;
	}
}
