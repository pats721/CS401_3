package data;
import java.util.ArrayList;
import java.util.Random;

import GameObjects.Player;
import helpers.Clock;

public class Spawn {
	public ArrayList<Enemy> enemies;
	private EnemyType[] enemyTypes;
	public int enemyCount;
	public int maxEnemy;
	public Tile spawn;
	public Tile[] path;
	public Tile endPoint;
	int wave = 2;
	private int previousEnemyCount = 0;
	
	public Spawn(){
		this.enemyCount = 0;
		this.maxEnemy = 15;
		this.enemies = new ArrayList<Enemy>();
		this.enemyTypes = new EnemyType[5];
		this.enemyTypes[0] = EnemyType.Robot;
		this.enemyTypes[1] = EnemyType.Alien;
		this.enemyTypes[2] = EnemyType.Virus;
		this.enemyTypes[3] = EnemyType.Poop;
		this.enemyTypes[4] = EnemyType.Devil;
	}
	
	//Increases the maxEnemy value for the next wave
	public void Reset(){
		if(enemyCount == maxEnemy){
			wave++;
			maxEnemy += (5 * (this.wave-1));
			previousEnemyCount = this.enemyCount;
		}
	}
	
	//Creates Enemy at an initial location
	//Each wave has a different format for spawning certain Enemy objects
	public void SpawnEnemy(Tile spawn, Tile endPoint, Tile[] path){
		this.spawn = spawn;
		this.path = path;
		if(enemyCount < maxEnemy){
			if(wave == 2){
				if((enemyCount - previousEnemyCount) % 3 == 0 ){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[1]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else{
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[0]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}
				enemyCount++;
			}else if(wave == 3){
				if(enemyCount - previousEnemyCount == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[1]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else if((enemyCount - previousEnemyCount) % 5 == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[2]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else if((enemyCount - previousEnemyCount) % 3 == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[2]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else{
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[1]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}
				enemyCount++;
			}else if(wave == 4){
				if(enemyCount - previousEnemyCount == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[3]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else if((enemyCount - previousEnemyCount) % 3 == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[4]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else{
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[0]);
					e.setBaseHealth(200); //Manually used to set a base health
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}
				enemyCount++;
			}
		}
	}
	
	//Moves each Enemy if certain conditions are met
	public void Move(){
		for(int i = 0; i < enemyCount; i++){
			if(enemies.get(i).currPosition == path.length){ //If the Enemy position is the endPoint the Enemy is set to not alive
				enemies.get(i).die();
			}else if(enemies.get(i).getHealth() == 0){ //If the Enemy health is equal to zero the Enemy is set to not alive
				enemies.get(i).die();
			}
			if(enemies.get(i).isAlive() == true){
				enemies.get(i).MoveSpeedDuration();
				enemies.get(i).move();
			}
		}
	}
	
	//If any enemy is still alive, returns true
	public boolean CheckIfAlive(ArrayList<Enemy> enemies){
		this.enemies = enemies;
		boolean isAlive = false;
		for(int i = 0; i < enemyCount; i++){
			if(this.enemies.get(i).isAlive() == true){
				System.out.println("isAlive" + i);
				isAlive = true;
			}
		}
		return isAlive;
	}
	
	//Draws graphics for Enemy
	public void DrawEnemy(){
		for(int i = 0; i < enemyCount; i++){
			if(enemies.get(i).isAlive()){
			enemies.get(i).DrawEnemy();
			}
		}
	}
	
	public int getMaxEnemy(){
		return this.maxEnemy;
	}
	
	public void setEnemies(ArrayList<Enemy> enemies){
		this.enemies = enemies;
	}
	
	public int GetEnemyCount(){
		return enemyCount;
	}
	
	public float getFirstEnemyX(){
		return enemies.get(0).getX();
	}
	
	public float getFirstEnemyY(){
		return enemies.get(0).getY();
	}
	
	public ArrayList<Enemy> getEnemyList(){
		return enemies;
	}
	
	public int getWave(){
		return wave;
	}
}
