package data;

import org.lwjgl.Sys;
import org.lwjgl.input.Mouse;
import org.newdawn.slick.Color;
import org.newdawn.slick.TrueTypeFont;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.util.ResourceLoader;

import GameObjects.Level;
import GameObjects.Player;
import GameObjects.Tower;
import UserInterface.Button;
import helpers.Artist;
import helpers.Clock;
import helpers.UIselector;

import static helpers.Artist.HEIGHT;
import static helpers.Clock.*;
import static helpers.UIselector.*;
import java.awt.Font;
import java.io.InputStream;
import java.util.ArrayList;

public class GameHandler {
	Tile[] path;
	Tile[][] map;
	TileGrid grid;
	Spawn spawner;
	Tile spawnPoint;
	Tile endPoint;
	Player user;
	public int enemyCount;
	public float timeSinceLastSpawn = 0;
	private float timeSinceLastWave = 0;
	public int spawnSpeed = 11;
	public Level currLevel;
	public boolean enemiesAlive = true;
	private ArrayList<Tower> towerList;
	private ArrayList<Enemy> enemies;
	private GameMenu ui;
	private int score = 0;
	private int lives = 3;
	Text text;
	private int money = 100;
	private int timeCounter = 0;
	public boolean nextWave = false;
	public boolean playing = true;
	public boolean wonGame = false;
	public boolean endGame = false;
	public Button abstractEndPoint;
	public int wave = 2;
	
	public GameHandler(){	
		this.currLevel = new Level();
		this.currLevel.nextLevel();
		this.spawner = new Spawn();
		this.grid = new TileGrid(currLevel.getMap());
		this.map = grid.getTileMap();
		this.path = grid.getPath();
		this.spawnPoint = grid.getSpawnPoint();
		this.endPoint = grid.getEndPoint();
		this.enemies = spawner.getEnemyList();
		this.ui = UIselector.getGameMenu();
		this.user = new Player(this.grid, this.enemies, this.ui);
		this.towerList = user.getTowerList();
		this.text = new Text();
		CheckIfAlive();
	}
	public boolean isPlaying(){
		return this.playing;
	}
	public void drawText(){
		text.drawString( String.valueOf("Money:" +this.money), 500, 950);
		text.drawString("Score:" + String.valueOf(this.score), 800, 950);
		text.drawString("Lives:" + String.valueOf(this.lives), 1075, 950);
		text.drawString("30", 64, 950);
		text.drawString("60", 192, 950);
		text.drawString("110", 320, 950);
	}
	public boolean paused(){
		boolean paused = this.user.paused();
		if(paused && !Clock.isPaused()){
			Clock.Pause();
		}else if(!paused && Clock.isPaused()){
			Clock.Pause();
		}
		return paused;
	}
	
	public boolean isEnd(){
		if(this.lives <= 0){
			return true;
		}return false;
	}
	public void updateGameMenu(){
		ui.update();
	}
	
	public void DrawGrid(){
		grid.Draw();
	}
	
	public void UpdateEnemy(){
		timeSinceLastSpawn += Delta();
		System.out.println(timeSinceLastSpawn);
		if(timeSinceLastSpawn > spawnSpeed){
			this.enemies = spawner.getEnemyList();
			Spawn();
		}
		LifeUpdate();
		Scoring();
	}
	
	public void LifeUpdate(){
		for(Enemy e: enemies){
			if(e.getCurrPosition() == path.length){
				if(!e.getAttacked())
				this.lives = this.lives - e.attackBase();
				if(this.lives <= 0){
					this.endGame = true;
				}
			}
		}
	}
	
	public void UpdateTower(){
		this.user.update(this.towerList, this.money);
		this.towerList = user.getTowerList();
		this.money -= this.user.getCost();
		if(user.isHolding())
		this.user.getTowerList().get(user.getHolding()).MoveTower(Mouse.getX(), HEIGHT - Mouse.getY());
		for(Tower t: towerList){
			if(t != null){
				if(t.isPlaced()){
					t.updateEnemyList(this.enemies);
					t.update();
					this.enemies = t.getEnemies();
					DestroyEnemies();
				}
			}
		}
	}
	
	public void DrawTower(){
		for(Tower t: towerList){
			if(t.isPlaced()){
				t.DrawTower();
			}
			if(user.getTempTower() == t){
				t.DrawTower();
			}
		}
	}
	
	public void DestroyEnemies(){
		ArrayList<Enemy> locEnemies = this.enemies;
			for(Enemy e: enemies){
				if(e.getHealth() <= 0){
					locEnemies.get(e.getIndex()).die();
				}
			}this.enemies = locEnemies;
	}
	
	public void Scoring(){
		for(Enemy e: enemies){
			if(!e.isAlive() && !e.getGotPoints()){
				this.score += e.getScore();;
				this.money += e.getScore()/2;
				e.gotPoints();		
			}
		}
	}
	
	public void CheckIfAlive(){
		if(spawner.GetEnemyCount() == spawner.getMaxEnemy()){
			if(!spawner.CheckIfAlive(enemies)){
				if(wave == 4){
					this.wonGame = true;
					this.endGame = true;
				}else{
					if(wave == spawner.getWave()){
						timeSinceLastWave+=Delta();
						if(timeSinceLastWave/10 > timeCounter){
							timeCounter++;
						}
						text.drawString("Wave " + this.wave + " is starting in: " + (8 - timeCounter), Artist.WIDTH/2 - 300, Artist.HEIGHT/2);
						if(timeSinceLastWave >= 60){
						spawner.Reset();
						enemies = spawner.getEnemyList();
						timeSinceLastWave = 0;
						timeCounter = 0;
						}
					}
				}
			}
		}
	}
	
	public boolean WonGame(){
		return wonGame;
	}
	public void Spawn(){
		timeSinceLastSpawn = 0;
		spawner.setEnemies(enemies);
		spawner.SpawnEnemy(spawnPoint, endPoint, path);
		if(wave < spawner.getWave()){
			wave++;
		}
		enemies = spawner.getEnemyList();
	}
	public void DrawEnemy(){
		spawner.DrawEnemy();
	}
	public void Movement(){
		spawner.Move();
	}
	public float GetEnemyX(){
		return spawner.getFirstEnemyX();
	}
	
	public float GetEnemyY(){
		return spawner.getFirstEnemyY();
	}
	
	public Spawn GetSpawner() {
		return this.spawner;
	}
	
	public boolean getEndGame(){
		return this.endGame;
	}
	
	public boolean getNextWave(){
		return this.nextWave;
	}
	
	public int getScore(){
		return this.score;
	}
}
