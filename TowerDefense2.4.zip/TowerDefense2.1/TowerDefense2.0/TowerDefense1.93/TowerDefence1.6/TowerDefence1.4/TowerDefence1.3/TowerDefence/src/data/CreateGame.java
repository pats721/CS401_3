package data;

import java.awt.Font;
import java.util.ArrayList;

import org.newdawn.slick.TrueTypeFont;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Artist;
import helpers.Clock;
import helpers.UIselector;
import helpers.UIselector.UIState;

public class CreateGame {
	GameHandler game;
	Text text = new Text();
	boolean nextWave = false;
	public CreateGame(){
		this.game = new GameHandler();
		
	}
	
	public void update(){
		if(game.paused()){
			UIselector.update();
			game.DrawGrid();
			game.updateGameMenu();
			game.DrawEnemy();
			game.DrawTower();
		}
		if(!game.paused()){
			UIselector.update();
		if(UIselector.uiState == UIState.LEVEL){
			Clock.update();
			game.DrawGrid();
			game.drawText();
			if(!game.getEndGame()){
				game.updateGameMenu();
					game.UpdateEnemy();
					game.Movement();
					game.DrawEnemy();
					game.UpdateTower();
					game.DrawTower();
					game.CheckIfAlive();
				}
			if(game.getEndGame()){
				text.drawString("Game Over", Artist.WIDTH/2 - 150, Artist.HEIGHT/2);
				text.drawString("Your Score is " + game.getScore(), Artist.WIDTH/2 - 200, Artist.HEIGHT/2  + 50);
			}
			if(game.WonGame()){
				text.drawString("You Won!", Artist.WIDTH/2 - 150, Artist.HEIGHT/2);
				text.drawString("Your Score is " + game.getScore(), Artist.WIDTH/2 - 200, Artist.HEIGHT/2  + 50);
			}
		}
		}
		
	}
	}