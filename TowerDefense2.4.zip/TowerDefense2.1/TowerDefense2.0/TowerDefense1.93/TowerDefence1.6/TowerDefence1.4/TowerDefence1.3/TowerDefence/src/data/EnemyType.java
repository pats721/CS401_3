package data;

public enum EnemyType {
	Fire("Fire32", true, 110, 2, 1, 10), Alien("Alien64", true, 150, 1, 1, 20), Virus("virus64", true, 130, 4, 1, 30), Devil("devil64", true, 4000, .5f, 3, 100);
	
	String texture;
	boolean build;
	int health;
	float moveSpeed;
	int dmg;
	int score;
	EnemyType(String texture, boolean build, int health, float moveSpeed, int dmg, int score){
		this.texture = texture;
		this.build = build;
		this.health = health;
		this.moveSpeed = moveSpeed;
		this.dmg = dmg;
		this.score = score;
	}
}

