package GameObjects;

import java.util.ArrayList;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import static helpers.Artist.*;

import UserInterface.UserInterface;
import data.Enemy;
import data.GameMenu;
import data.Text;
import data.TileGrid;
import data.TileType;
import helpers.UIselector;
import helpers.UIselector.UIState;

public class Player {

	private TileGrid grid;
	private TileType[] types;
	private TowerType[] towertypes;
	private int index;
	private ArrayList<Tower> towerList;
	private boolean leftMouseButtonDown = true;
	private boolean rightMouseButtonDown = true;
	private boolean keyPisDown = true;
	private boolean gamePaused = false;
	private int holding;
	private GameMenu ui;
	private Tower tempTower;
	private boolean isHolding = false;
	private int cost = 0;
	private Text text = new Text();
	
	public Player(TileGrid grid, ArrayList<Enemy> enemies, GameMenu ui ) {
		this.grid = grid;
		this.types = new TileType[3];
		this.towertypes = new TowerType[3];
		this.index = 0;
		this.towerList = new ArrayList<Tower>();
		this.types[0] = TileType.Path;
		this.types[1] = TileType.Water;
		this.types[2] = TileType.Ground;
		this.towertypes[0] = TowerType.BasicSquirt;
		this.towertypes[1] = TowerType.MediumSatellite;
		this.towertypes[2] = TowerType.HighVolcano;
		this.ui = ui;	
		this.tempTower = null;
	}

	public void setTile() {
		grid.SetTile((int) Math.floor(Mouse.getX() / 64), (int) Math.floor((HEIGHT - Mouse.getY() - 1) / 64),
				types[index]);
	}

	public void update(ArrayList<Tower> towerList, int money) {
		this.towerList = towerList;
		int towerIndex;
		ui.update();
		if(ui.updateButtons() == 0 && !leftMouseButtonDown){
			if(tempTower==null){
				towerIndex = ui.updateButtons();
				tempTower = new Tower("Squirt",towertypes[towerIndex]);
				this.towerList.add(tempTower);
				holding = towerList.size()-1;
				this.isHolding = true;
				System.out.println(holding);
			}
		}else if(ui.updateButtons() == 1 && !leftMouseButtonDown){
			if(tempTower==null){
				towerIndex = ui.updateButtons();
				tempTower = new Tower("Satellite",towertypes[towerIndex]);
				this.towerList.add(tempTower);
				holding = towerList.size()-1;
				this.isHolding = true;
				System.out.println(holding);
			}
		}else if(ui.updateButtons() == 2 && !leftMouseButtonDown){
			if(tempTower==null){
				towerIndex = ui.updateButtons();
				tempTower = new Tower("Volcano",towertypes[towerIndex]);
				this.towerList.add(tempTower);
				holding = towerList.size()-1;
				this.isHolding = true;
				System.out.println(holding);
			}
		}else if(this.tempTower!=null){
			if(Mouse.isButtonDown(0) && Mouse.getY()<= 960 && money >= tempTower.getCost()){
				if(grid.GetTile((int) Math.floor(Mouse.getX() / 64), (int) Math.floor((HEIGHT - Mouse.getY() - 1) / 64)).getType() == TileType.Water){
					this.towerList.get(holding).SetTower(grid.GetTile((int) Math.floor(Mouse.getX() / 64), (int) Math.floor((HEIGHT - Mouse.getY() - 1) / 64)));
					grid.GetTile((int) Math.floor(Mouse.getX() / 64), (int) Math.floor((HEIGHT - Mouse.getY() - 1) / 64)).setOccupance(true);;
					this.cost += this.towerList.get(holding).getCost();
					tempTower = null;
					this.isHolding = false;
				}
			}
			else if(Mouse.isButtonDown(0) && Mouse.getY() <= 960 &&  money < tempTower.getCost()){
				text.drawString("Not enough Money", Mouse.getX()-30, 960- Mouse.getY()-30);
			}
		}leftMouseButtonDown = Mouse.getEventButtonState();
		
		if(Mouse.isButtonDown(1) && !rightMouseButtonDown){
			tempTower = null;
			this.isHolding = false;
		}rightMouseButtonDown = Mouse.getEventButtonState();
			// Keyboard Input.
			while (Keyboard.next()) {
				if (Keyboard.getEventKey() == Keyboard.KEY_RIGHT && Keyboard.getEventKeyState()) {
					moveIndex();
				}
				if (Keyboard.getEventKey() == Keyboard.KEY_RIGHT && Keyboard.getEventKeyState()) {
					moveIndex();
				}
				if (Keyboard.getEventKey() == Keyboard.KEY_T && Keyboard.getEventKeyState()) {
					towerList.add(new Tower("fkghhg", grid.GetTile(18, 9), TowerType.BasicSquirt));
				}
		}
	}
	public int getCost(){
		int tempCost = this.cost;
		this.cost = 0;
		return tempCost;
	}
	public boolean isHolding(){
		return this.isHolding;
	}
	public int getHolding(){
		return this.holding;
	}
	public boolean paused(){
		if(Keyboard.isKeyDown(Keyboard.KEY_P) && !keyPisDown) {
		    gamePaused = !gamePaused;
		}keyPisDown = Keyboard.isKeyDown(Keyboard.KEY_P);
		return gamePaused;
	}
	private void moveIndex() {
		index++;
		if (index > types.length - 1) {
			index = 0;
		}
	}

	public ArrayList<Tower> getTowerList() {
		return towerList;
	}

	public void setTowerList(ArrayList<Tower> towerList) {
		this.towerList = towerList;
	}
}