package data;
import java.util.ArrayList;

import helpers.Clock;

public class Spawn {
	public ArrayList<Enemy> enemies;
	public int enemyCount;
	public int maxEnemy;
	public Tile spawn;
	public Tile[] path;
	public Tile endPoint;
	public Spawn(int maxEnemyCount){
		this.enemyCount = 0;
		this.maxEnemy = maxEnemyCount;
		this.enemies = new ArrayList<Enemy>(maxEnemyCount);
	}
	
	public void SpawnEnemy(Tile spawn, Tile endPoint, Tile[] path){
		this.spawn = spawn;
		this.path = path;
		if(enemyCount < maxEnemy){
			
			Enemy e = new Enemy(spawn, endPoint, path);
			enemies.add(e);
			
			System.out.println("Enemy" + enemyCount + ":" + e);
			enemyCount++;
		}
	}
	
	public void Move(){
		for(int i = 0; i < enemyCount; i++){
			if(enemies.get(i).currPosition == path.length){
				enemies.get(i).die();
			}
			if(enemies.get(i).isAlive() == true){
				enemies.get(i).move();
			}
		}
	}
	public int GetEnemyCount(){
		return enemyCount;
	}
	
	public void DrawEnemy(){
		for(int i = 0; i < enemyCount; i++){
			if(enemies.get(i).isAlive()){
			enemies.get(i).DrawEnemy();
			}
		}
	}
	
	public void DestroyEnemy(){
		
	}

	public float getFirstEnemyX(){
		return enemies.get(0).getX();
	}
	public float getFirstEnemyY(){
		return enemies.get(0).getY();
	}
}
