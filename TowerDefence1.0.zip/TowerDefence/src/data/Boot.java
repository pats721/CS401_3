package data;

import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.newdawn.slick.opengl.Texture;

import GameObjects.Tower;
import GameObjects.TowerType;
import helpers.Clock;
import helpers.UIselector;

import static org.lwjgl.opengl.GL11.*;
import static helpers.Artist.*;

public class Boot{
	private static final int GL_PROTECTION = 0;
	public Boot() {
		
		/*		Display.setTitle("Tower Defense");
		try {
			Display.setDisplayMode(new DisplayMode(700,500));
			Display.create();
		} catch (LWJGLException e) {
			e.printStackTrace();
		}
		*/
		BeginSession();
		
		
		Level level = new Level();
		level.nextLevel();
		
		Spawn enemySpawn = new Spawn(level.getMaxEnemy());
		TileGrid grid = new TileGrid(level.getMap());
		GameHandler game = new GameHandler(grid.getPath(), grid.getTileMap(), enemySpawn, grid.getSpawnPoint(), grid.getEndPoint());
		Tower tower = new Tower("Basic",grid.GetTile(7, 1), TowerType.Basic);
		
		while (!Display.isCloseRequested()){
			UIselector.update();
			
			/*grid.Draw();
			
			game.Update();
			game.Movement();
			
			tower.update(game.GetEnemyX(), game.GetEnemyY());*/
			Display.update();
			Display.sync(60);
			
			
		}
		Display.destroy();
	}
	
	public static void main(String[] args){
		new Boot();
	}
}
