package data;

public enum TileType {
	Path("brick1", true), Water("Grass4", false), Ground("grd2", true);
	
	String texture;
	boolean build;
	
	TileType(String texture, boolean build) {
		this.texture = texture;
		this.build = build;
		
	}

}
