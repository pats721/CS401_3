package data;
import java.util.ArrayList;
import java.util.Random;

import GameObjects.Player;
import helpers.Clock;

public class Spawn {
	public ArrayList<Enemy> enemies;
	private EnemyType[] enemyTypes;
	public int enemyCount;
	public int maxEnemy;
	public Tile spawn;
	public Tile[] path;
	public Tile endPoint;
	int wave = 2;
	private int previousEnemyCount = 0;
	
	public Spawn(){
		this.enemyCount = 0;
		this.maxEnemy = 15;
		this.enemies = new ArrayList<Enemy>();
		this.enemyTypes = new EnemyType[4];
		this.enemyTypes[0] = EnemyType.Robot;
		this.enemyTypes[1] = EnemyType.Alien;
		this.enemyTypes[2] = EnemyType.Virus;
		this.enemyTypes[3] = EnemyType.Devil;
	}
	
	public void SpawnEnemy(Tile spawn, Tile endPoint, Tile[] path){
		this.spawn = spawn;
		this.path = path;
		if(enemyCount < maxEnemy){
			if(wave == 2){
				if((enemyCount - previousEnemyCount) % 3 == 0 ){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[1]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else{
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[0]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}
				enemyCount++;
			}else if(wave == 3){
				if(enemyCount - previousEnemyCount == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[1]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else if((enemyCount - previousEnemyCount) % 5 == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[2]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else if((enemyCount - previousEnemyCount) % 3 == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[2]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else{
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[1]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}
				enemyCount++;
			}else if(wave == 4){
				if(enemyCount - previousEnemyCount == 0){
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[3]);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}else{
					Enemy e = new Enemy(spawn, endPoint, path, enemyTypes[0]);
					e.setBaseHealth(200);
					enemies.add(e);
					enemies.get(enemyCount).setIndex(enemyCount);
					System.out.println("Enemy" + enemyCount + ":" + e);
				}
				enemyCount++;
			}
		}
	}
	
	public int getMaxEnemy(){
		return this.maxEnemy;
	}
	
	public void Reset(){
		if(enemyCount == maxEnemy){
			wave++;
			maxEnemy += 15;
			previousEnemyCount = this.enemyCount;
		}
	}
	
	public boolean CheckIfAlive(ArrayList<Enemy> enemies){
		this.enemies = enemies;
		boolean isAlive = false;
		for(int i = 0; i < enemyCount; i++){
			if(this.enemies.get(i).isAlive() == true){
				System.out.println("isAlive" + i);
				isAlive = true;
			}
		}
		return isAlive;
	}
	
	public void setEnemies(ArrayList<Enemy> enemies){
		this.enemies = enemies;
	}
	
	public void Move(){
		for(int i = 0; i < enemyCount; i++){
			if(enemies.get(i).currPosition == path.length){
				enemies.get(i).die();
			}else if(enemies.get(i).getHealth() == 0){
				enemies.get(i).die();
			}
			if(enemies.get(i).isAlive() == true){
				enemies.get(i).MoveSpeedDuration();
				enemies.get(i).move();
			}
		}
	}
	public int GetEnemyCount(){
		return enemyCount;
	}
	
	public void DrawEnemy(){
		for(int i = 0; i < enemyCount; i++){
			if(enemies.get(i).isAlive()){
			enemies.get(i).DrawEnemy();
			}
		}
	}

	public float getFirstEnemyX(){
		return enemies.get(0).getX();
	}
	
	public float getFirstEnemyY(){
		return enemies.get(0).getY();
	}
	
	public ArrayList<Enemy> getEnemyList(){
		return enemies;
	}
	
	public int getWave(){
		return wave;
	}
}
